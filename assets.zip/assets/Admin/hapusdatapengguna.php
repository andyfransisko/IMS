<?php
include('../../connect.php');
$tangkap_id_pengguna = $_GET['id'];
$status_delete = "0";

$query = mysqli_query($koneksi, "UPDATE 
pengguna SET user_delete='$idsaya',waktu_delete=NOW(),
status_delete='$status_delete', status_pengguna='$status_delete' 
WHERE 
id_pengguna ='$tangkap_id_pengguna'");

if($query){
  header('location:pengguna.php');
}
?>