<!DOCTYPE html>
<html lang="en">
<?php
SESSION_START();
$idsaya = $_SESSION['myid'];
include('../../connect.php');
?>
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Inventory LAB Systems</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="vendors/iconfonts/mdi/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="vendors/css/vendor.bundle.base.css">
  <link rel="stylesheet" href="vendors/css/vendor.bundle.addons.css">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="css/style.css">
  <!-- endinject -->
  <link rel="icon" href="../img/logo2.png" type="image/x-icon"/>
</head>

<body>
   <?php
     include('split/head.php');

     include('split/left.php');
    ?>

    <?php
    $query = mysqli_query($koneksi,"SELECT * from pengguna where id_pengguna='$idsaya' ");
    $data = mysqli_fetch_array($query);
    ?>
    
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-lg-12 grid-margin">
              <div class="card">
                <div class="card-body"> 
                  <h4 class="card-title">Form Edit pengguna</h4>

                    <form class="forms-sample" method="POST">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Email</label>
                          <div class="col-sm-9">
                             <input type="email" class="form-control" id="email" name="email" value="<?php echo $data['email'];?>" required="required">
                          </div>
                        </div>
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Kata Sandi</label>
                          <div class="col-sm-9">
                             <input type="text" class="form-control" id="katasandi" name="katasandi" value="<?php echo $data['kata_sandi'];?>" required="required">
                          </div>
                        </div>
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Nama Lengkap</label>
                          <div class="col-sm-9">
                             <input type="text" class="form-control" id="namalengkap" name="namalengkap" value="<?php echo $data['nama_lengkap'];?>" required="required">
                          </div>
                        </div>
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Tanggal Lahir</label>
                          <div class="col-sm-9">
                             <input type="date" class="form-control" id="tanggallahir" name="tanggallahir" value="<?php echo $data['tanggal_lahir'];?>" required="required">
                          </div>
                        </div>
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Alamat</label>
                          <div class="col-sm-9">
                             <input type="text" class="form-control" id="alamat" name="alamat" value="<?php echo $data['alamat'];?>" required="required">
                          </div>
                        </div>
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">No HP</label>
                          <div class="col-sm-9">
                             <input type="text" class="form-control" id="nohp" name="nohp" value="<?php echo $data['no_hp'];?>" required="required">
                          </div>
                        </div>
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Tanggal Masuk</label>
                          <div class="col-sm-9">
                             <input type="date" class="form-control" id="tanggalmasuk" name="tanggalmasuk" value="<?php echo $data['tanggal_masuk'];?>" required="required">
                          </div>
                        </div>
                        <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Status Pengguna</label>
                          <div class="col-sm-4">
                            <div class="form-radio">
                              <label class="form-check-label">
                                <input type="radio" class="form-check-input" name="statuspengguna" id="1" value="1" 
                                <?php if($data['status_pengguna']=="1") {echo "checked";}?> > Aktif
                              </label>
                            </div>
                          </div>
                          <div class="col-sm-5">
                            <div class="form-radio">
                              <label class="form-check-label">
                                <input type="radio" class="form-check-input" name="statuspengguna" id="0" value="0"
                                <?php if($data['status_pengguna']=="0") {echo "checked";}?> >Tidak Aktif
                              </label>
                            </div>
                          </div>
                        </div>
                      </div>
                        
                        <button type="submit" class="btn btn-success mr-2" name="submit">Submit</button>
                        <a href="pengguna.php"><button type ="button" class="btn btn-light">Cancel</button></a>
                    </form>
                    <?php
                      if(isset($_POST['submit']))
                      {
                        include('../../connect.php');
                        $idsaya = $_SESSION['myid'];
                        $nama_lengkap = $_POST['namalengkap'];
                        $email = $_POST['email'];
                        $kata_sandi = $_POST['katasandi'];
                        $tanggal_lahir = $_POST['tanggallahir'];
                        $alamat = $_POST['alamat'];
                        $no_hp = $_POST['nohp'];
                        $tanggal_masuk = $_POST['tanggalmasuk'];
                        $status_pengguna = $_POST['statuspengguna'];

                        $query = mysqli_query($koneksi, "UPDATE pengguna SET nama_lengkap ='$nama_lengkap',email ='$email',kata_sandi ='$kata_sandi',tanggal_lahir ='$tanggal_lahir',alamat ='$alamat',no_hp ='$no_hp',tanggal_masuk ='$tanggal_masuk',status_pengguna ='$status_pengguna' WHERE id_pengguna='$idsaya'");

                        echo "<script type='text/javascript'>window.top.location='dashboard.php';</script>"; exit;
                      }
                    ?>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
        <footer class="footer">
          <div class="container-fluid clearfix">
            <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright © 2018
              <a href="http://www.bootstrapdash.com/" target="_blank">Bootstrapdash</a>. All rights reserved.</span>
              <span class="float-none float-sm-right  mt-1 mt-sm-0 text-center" style ="color: #000f99;">
                <b>SISTECH UPH</b>
              </span>
            </span>
          </div>
        </footer>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- plugins:js -->
  <script src="vendors/js/vendor.bundle.base.js"></script>
  <script src="vendors/js/vendor.bundle.addons.js"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="js/off-canvas.js"></script>
  <script src="js/misc.js"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="js/dashboard.js"></script>
  <!-- End custom js for this page-->
</body>

</html>