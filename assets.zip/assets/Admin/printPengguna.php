<?php
require('fpdf/fpdf.php');
require('../../connect.php');
class PDF extends FPDF {
	function Header()
	{
		$this->SetFont('Arial','B',15);
		$this->Ln(5);
	}
	function Footer()
	{
		$this->SetY(-10);
		$this->setFont('Arial','B',10);
		$this->Cell(0,0,'SISTECH UPH',0,0,'R');
		$this->Cell(0,10,'Page '.$this->PageNo()." / {pages}",0,0,'C');
	}
}

$pdf = new PDF('l','mm','A4');
$pdf->SetAutoPageBreak(true,15);
$pdf->AliasNbPages('{pages}');
$pdf->AddPage();
$pdf->setFONT('Arial','',20);
$pdf->Image('logo.png',10,10,50);
$pdf->Cell(269,30,'',0,1);
$pdf->Cell(269,5,'REPORT',0,1,'R');
$pdf->Cell(269,10,'',0,1);

//Tabel data
$pdf->setFONT('Arial','',10);
//Cell(width,height,'text',border,end-line)
$pdf->Cell(10,5,'No.',1,0);
$pdf->Cell(29.8,5,'Nama Lengkap',1,0);
$pdf->Cell(45,5,'Email',1,0);
$pdf->Cell(29.8,5,'Kata Sandi',1,0);
$pdf->Cell(29.8,5,'Tanggal Lahir',1,0);
$pdf->Cell(29.8,5,'Alamat',1,0);
$pdf->Cell(29.8,5,'Nomor HP',1,0);
$pdf->Cell(29.8,5,'Tanggal Masuk',1,0);
$pdf->Cell(29.8,5,'Status Pengguna',1,1);

$query = mysqli_query($koneksi, "SELECT * from pengguna JOIN detail_pengguna ON pengguna.id_pengguna=detail_pengguna.id_pengguna JOIN status ON detail_pengguna.id_status=status.id_status");
$nomor="1";
while($data = mysqli_fetch_array($query))
{
$pdf->Cell(10,5,$nomor,1,0);
$pdf->Cell(29.8,5,$data['nama_lengkap'],1,0);
$pdf->Cell(45,5,$data['email'],1,0);
$pdf->Cell(29.8,5,$data['kata_sandi'],1,0);
$pdf->Cell(29.8,5,$data['tanggal_lahir'],1,0);
$pdf->Cell(29.8,5,$data['alamat'],1,0);
$pdf->Cell(29.8,5,$data['no_hp'],1,0);
$pdf->Cell(29.8,5,$data['tanggal_masuk'],1,0);
$pdf->Cell(29.8,5,$data['nama_status'],1,1);
$nomor++;
}

//Space footer
$pdf->Cell(189,10,'',0,1);
$pdf->Output();