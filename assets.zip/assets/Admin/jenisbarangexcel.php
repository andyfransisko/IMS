<?php
include('../../connect.php');
$output='';
if(isset($_POST['export_excel']))
{
	$result = mysqli_query($koneksi , "SELECT * FROM jenis_barang");
	if(mysqli_num_rows($result) > 0)
	{
		$output .= '<table class="table" border="1">
		<tr>
			<th>
            ID Jenis Barang
            </th>
            <th>
              Nama Jenis Barang
            </th>
          </tr>
         ';
         while($data = mysqli_fetch_array($result))
         {
         	$output.='
         	<tr>
         	<td>'.$data["id_jenisBarang"].'</td>
         	<td>'.$data["nama_jenisBarang"].'</td>
         	</tr>
         	';
         }
                  $output .= '</table>';
         header("Content-Type: application/xls");
         header("Content-Disposition:attachment; filename=jenisBarang.xls");
         echo $output;
	}
}
?>