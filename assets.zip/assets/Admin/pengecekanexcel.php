<?php
include('../../connect.php');
$output='';
if(isset($_POST['export_excel']))
{
	$result = mysqli_query($koneksi , "SELECT * FROM pengecekan");
	if(mysqli_num_rows($result) > 0)
	{
		$output .= '<table class="table" border="1">
		<tr>
			<th>
            ID Pengecekan
            </th>
            <th>
               ID Pengguna
            </th>
            <th>
               Waktu Pengecekan
            </th>
            <th>
               ID Status Barang
            </th>
            <th>
               ID Barang
            </th>
          </tr>
         ';
         while($data = mysqli_fetch_array($result))
         {
         	$output.='
         	<tr>
         	<td>'.$data["id_pengecekan"].'</td>
         	<td>'.$data["id_pengguna"].'</td>
            <td>'.$data["waktu_pengecekan"].'</td>
            <td>'.$data["id_statusBarang"].'</td>
            <td>'.$data["id_barang"].'</td>
         	</tr>
         	';
         }
                  $output .= '</table>';
         header("Content-Type: application/xls");
         header("Content-Disposition:attachment; filename=pengecekan.xls");
         echo $output;
	}
}
?>