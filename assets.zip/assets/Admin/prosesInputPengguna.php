<?php
if(isset($_POST['submit']))
{
 include('../../connect.php');
 $id_pengguna = $_POST['idpengguna'];
 $email = $_POST['email'];
 $kata_sandi = $_POST['katasandi'];
 $nama_lengkap = $_POST['namalengkap'];
 $tanggal_lahir = $_POST['tanggallahir'];
 $alamat = $_POST['alamat'];
 $no_hp = $_POST['nohp'];
 $tanggal_masuk = $_POST['tanggalmasuk'];
 $status_pengguna = $_POST['statuspengguna'];
 $id_status = $_POST['idstatus'];
 SESSION_START();
 $idsaya = $_SESSION['myid'];

 
      $query = mysqli_query($koneksi, "SELECT * FROM detail_pengguna" );

      $checkBaris = mysqli_num_rows($query);
      $PK = 100001 + $checkBaris;
      $PK1 = "DP" . $PK;
    
	$query = mysqli_query($koneksi, 
	"INSERT INTO 
	pengguna 
	(id_pengguna,email,kata_sandi,nama_lengkap,
	tanggal_lahir,alamat,no_hp,tanggal_masuk,
	status_pengguna,user_add,waktu_add,status_delete) 
	VALUES 
	('$id_pengguna','$email','$kata_sandi',
	'$nama_lengkap','$tanggal_lahir','$alamat',
	'$no_hp','$tanggal_masuk','$status_pengguna',
	'$idsaya', NOW(),'1')");

 	$query2 = mysqli_query($koneksi, 
 	"INSERT INTO detail_pengguna 
	 (id_detailPengguna,id_pengguna,id_status) 
	 VALUES 
	 ('$PK1','$id_pengguna','$id_status')");


 if(!$query && !$query2)
 {
  echo "Gagal Simpan Data";
 }
 header('location:pengguna.php');
}
else
{
 header('location:pengguna.php');
}
?>