<!DOCTYPE html>
<html lang="en">
<?php
include('../../connect.php');
?>
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Inventory LAB Systems</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="vendors/iconfonts/mdi/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="vendors/css/vendor.bundle.base.css">
  <link rel="stylesheet" href="vendors/css/vendor.bundle.addons.css">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="css/style.css">
  <!-- endinject -->
  <link rel="icon" href="../img/logo2.png" type="image/x-icon"/>
</head>

<body>
   <?php
     include('split/head.php');

     include('split/left.php');
    ?>
    <?php
      $query = mysqli_query($koneksi, "SELECT * FROM pengecekan " );

      $checkBaris = mysqli_num_rows($query);
      $PK = 100001 + $checkBaris;
    ?>
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-lg-12 grid-margin">
              <div class="card">
                <div class="card-body"> 
                  <h4 class="card-title">Form Input Pengecekan</h4>

                    <form class="forms-sample" method="POST" action="prosesInputPengecekan.php">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">ID Pengecekan</label>
                          <div class="col-sm-9">
                            <input type="Text" class="form-control" name="idpengecekan" id="PKCEK" readonly
                            value="<?php
                              echo "CEK".$PK;
                            ?>">
                          </div>
                        </div>
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">ID Pengguna</label>
                          <div class="col-sm-9">
                            <select name="idpengguna" class="form-control">
                              <?php
                              $query_pengguna = mysqli_query($koneksi, "SELECT * FROM pengguna");
                              while($data = mysqli_fetch_array($query_pengguna))
                              {
                                ?>
                                <option value="<?php echo $data['id_pengguna']; ?>">
                                <?php echo $data['id_pengguna']." - ".$data['nama_lengkap']; ?>
                              </option>
                              <?php } ?>
                            </select>
                          </div>
                        </div>
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Waktu Pengecekan</label>
                          <div class="col-sm-9">
                            <input type="date" class="form-control" name="waktupengecekan" id="">
                          </div>
                        </div>
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">ID Status Barang</label>
                          <div class="col-sm-9">
                            <select name="idstatusbarang" class="form-control">
                              <?php
                              $query_statusBarang = mysqli_query($koneksi, "SELECT * FROM status_barang");
                              while($data = mysqli_fetch_array($query_statusBarang))
                              {
                                ?>
                                <option value="<?php echo $data['id_statusBarang']; ?>">
                                <?php echo $data['id_statusBarang']." - ".$data['statusBarang']; ?>
                              </option>
                              <?php } ?>
                            </select>
                          </div>
                        </div>
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">ID Barang</label>
                          <div class="col-sm-9">
                            <select name="idbarang" class="form-control">
                              <?php
                              $query_barang = mysqli_query($koneksi, "SELECT * FROM barang");
                              while($data = mysqli_fetch_array($query_barang))
                              {
                                ?>
                                <option value="<?php echo $data['id_barang']; ?>">
                                <?php echo $data['id_barang']; ?>
                              </option>
                              <?php } ?>
                            </select>
                          </div>
                        </div>
                        <button type="submit" class="btn btn-success mr-2" name="submit">Submit</button>
                        <a href="pengecekan.php"><button class="btn btn-light">Cancel</button></a>
                    </form>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
        <footer class="footer">
          <div class="container-fluid clearfix">
            <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright © 2018
              <a href="http://www.bootstrapdash.com/" target="_blank">Bootstrapdash</a>. All rights reserved.</span>
              <span class="float-none float-sm-right  mt-1 mt-sm-0 text-center" style ="color: #000f99;">
                <b>SISTECH UPH</b>
              </span>
          </div>
        </footer>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- plugins:js -->
  <script src="vendors/js/vendor.bundle.base.js"></script>
  <script src="vendors/js/vendor.bundle.addons.js"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="js/off-canvas.js"></script>
  <script src="js/misc.js"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="js/dashboard.js"></script>
  <!-- End custom js for this page-->
</body>

</html>