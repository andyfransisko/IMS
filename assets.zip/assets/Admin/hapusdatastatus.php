<?php
include('../../connect.php');
$tangkap_id_status = $_GET['id'];
$status_delete = "0";

$query = mysqli_query($koneksi, 
"UPDATE status SET user_delete='$idsaya',
waktu_delete=NOW(),status_delete='$status_delete' 
WHERE id_status ='$tangkap_id_status'");

if($query){
  echo "<script type='text/javascript'>window.top.location='status.php';</script>"; exit;
}
?>