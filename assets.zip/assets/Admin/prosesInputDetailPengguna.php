<?php
if(isset($_POST['submit']))
{
	include('../../connect.php');
	$id_detailPengguna = $_POST['iddetailpengguna'];
	$id_pengguna = $_POST['idpengguna'];
	$id_status = $_POST['idstatus'];


	$query = mysqli_query($koneksi, "INSERT INTO detail_pengguna (id_detailPengguna,id_pengguna,id_status) VALUES ('$id_detailPengguna','$id_pengguna','$id_status')");

	if(!$query)
	{
		echo "Gagal Simpan Data";
	}
	header('location:detailPengguna.php');
}
else
{
	header('location:detailPengguna.php');
}
?>