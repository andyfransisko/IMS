<?php
include('../../connect.php');
$output='';
if(isset($_POST['export_excel']))
{
   $result = mysqli_query($koneksi , "SELECT * FROM laporan");
   if(mysqli_num_rows($result) > 0)
   {
      $output .= '<table class="table" border="1">
      <tr>
         <th>
            ID Laporan
         </th>
         <th>
            ID Pengguna
          </th>
         <th>
            Waktu Laporan
         </th>
         <th>
            ID Ruangan
          </th>
         <th>
          Index Barang
         </th>
         <th>
          ID Jenis Barang
         </th> 
          <th>
            ID Status Barang
         </th>
          <th>
          Keterangan
         </th>
          </tr>
         ';
         while($data = mysqli_fetch_array($result))
         {
            $output.='
            <tr>
            <td>'.$data["id_laporan"].'</td>
            <td>'.$data["id_pengguna"].'</td>
            <td>'.$data["waktu_laporan"].'</td>
            <td>'.$data["id_ruangan"].'</td>
            <td>'.$data["index_barang"].'</td>
            <td>'.$data["id_jenisBarang"].'</td>
            <td>'.$data["id_statusBarang"].'</td>
            <td>'.$data["keterangan"].'</td>
            </tr>
            ';
         }
                  $output .= '</table>';
         header("Content-Type: application/xls");
         header("Content-Disposition:attachment; filename=laporan.xls");
         echo $output;
   }
}
?>