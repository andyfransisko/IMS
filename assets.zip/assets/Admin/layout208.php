<!DOCTYPE html>
<html lang="en">

<head>
<?php
session_start();
?>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Inventory LAB Systems</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="vendors/iconfonts/mdi/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="vendors/css/vendor.bundle.base.css">
  <link rel="stylesheet" href="vendors/css/vendor.bundle.addons.css">
  
  <!-- endinject -->
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/style2.css">
  <!-- endinject -->
  <link rel="icon" href="../img/logo2.png" type="image/x-icon"/>
</head>

<body>
<?php
      session_start();

      $namasaya = $_SESSION['myname'];

      $idsaya = $_SESSION['myid'];

      $statussaya = $_SESSION['mystatus'];

      if(!isset($namasaya))
      {
        header('location:../../index.php');
      }
     
      
    /* Untuk Super Admin */
     if($statussaya == "Super Admin")
     {
      include('split/head.php');
      include('split/left.php');
     }

     /* Untuk Admin */
     else if($statussaya == "Admin")
     {
      include('split/head3.php');
      include('split/left3.php');
      
     }

     /* Untuk User */
     else if($statussaya == "User")
     {
      include('split/head3.php');
      include('split/left5.php');
     }
    ?>
    
      <div class="main-panel">
        <div class="content-wrapper">
  
        <?php
            $nomor = array("1","2","3","4","5","6","7","8","9","10"
                          ,"11","12","13","14","15","16","17","18","19","20"
                          ,"21","22","23","24","25","26","27","28");
            $nomor1 = 0;
            $ruangan = "R100004";
          ?>
         
          <div class="row">
            <div class="col-12 grid-margin">
              <div class="card">
                <div class="card-body">
                  <center><h1>F 208</h1></center>
                  <div class="fluid-container">
                  <center>
                  <table border="0" width ="95%" cellpadding ="5%">
                      <tr align = "center">
                        <td width="11.25%" height= "20%" colspan="8">&nbsp;</td>
                      </tr>
                      <tr align = "center">
                        <td colspan="8"><div class="b6">Lecturer's Table</div></td>
                      </tr>
                      <tr align = "center">
                      <td width="11.25%">
                          <a style="text-decoration: none; cursor:default;color:black;" href = "detail208.php?idR=<?php echo "$ruangan"; ?>&idI=<?php echo $nomor[$nomor1];?>" >
                          <div class="b3">#<?php echo $nomor[$nomor1]; $nomor1++; ?></div></a></td>
                        <td width="11.25%"></td>
                        <td width="11.25%">
                          <a style="text-decoration: none; cursor:default;color:black;" href = "detail208.php?idR=<?php echo "$ruangan"; ?>&idI=<?php echo $nomor[$nomor1];?>" >
                          <div class="b1">#<?php echo $nomor[$nomor1]; $nomor1++; ?></div></a></td>
                          <td width="11.25%">
                          <a style="text-decoration: none; cursor:default;color:black;" href = "detail208.php?idR=<?php echo "$ruangan"; ?>&idI=<?php echo $nomor[$nomor1];?>" >
                          <div class="b1">#<?php echo $nomor[$nomor1]; $nomor1++; ?></div></a></td>
                          <td width="11.25%">
                          <a style="text-decoration: none; cursor:default;color:black;" href = "detail208.php?idR=<?php echo "$ruangan"; ?>&idI=<?php echo $nomor[$nomor1];?>" >
                          <div class="b1">#<?php echo $nomor[$nomor1]; $nomor1++; ?></div></a></td>
                          <td width="11.25%">
                          <a style="text-decoration: none; cursor:default;color:black;" href = "detail208.php?idR=<?php echo "$ruangan"; ?>&idI=<?php echo $nomor[$nomor1];?>" >
                          <div class="b1">#<?php echo $nomor[$nomor1]; $nomor1++; ?></div></a></td>
                        <td width="11.25%"></td>
                        <td width="11.25%">
                          <a style="text-decoration: none; cursor:default;color:black;" href = "detail208.php?idR=<?php echo "$ruangan"; ?>&idI=<?php echo $nomor[$nomor1];?>" >
                          <div class="b3">#<?php echo $nomor[$nomor1]; $nomor1++; ?></div></a></td>
                        <td width = "2%"rowspan = "6"><div class="b2">DOOR</div></td>
                      </tr>
                      <tr align = "center">
                      <td width="11.25%">
                          <a style="text-decoration: none; cursor:default;color:black;" href = "detail208.php?idR=<?php echo "$ruangan"; ?>&idI=<?php echo $nomor[$nomor1];?>" >
                          <div class="b3">#<?php echo $nomor[$nomor1]; $nomor1++; ?></div></a></td>
                        <td width="11.25%"></td>
                        <td width="11.25%">
                          <a style="text-decoration: none; cursor:default;color:black;" href = "detail208.php?idR=<?php echo "$ruangan"; ?>&idI=<?php echo $nomor[$nomor1];?>" >
                          <div class="b1">#<?php echo $nomor[$nomor1]; $nomor1++; ?></div></a></td>
                          <td width="11.25%">
                          <a style="text-decoration: none; cursor:default;color:black;" href = "detail208.php?idR=<?php echo "$ruangan"; ?>&idI=<?php echo $nomor[$nomor1];?>" >
                          <div class="b1">#<?php echo $nomor[$nomor1]; $nomor1++; ?></div></a></td>
                          <td width="11.25%">
                          <a style="text-decoration: none; cursor:default;color:black;" href = "detail208.php?idR=<?php echo "$ruangan"; ?>&idI=<?php echo $nomor[$nomor1];?>" >
                          <div class="b1">#<?php echo $nomor[$nomor1]; $nomor1++; ?></div></a></td>
                          <td width="11.25%">
                          <a style="text-decoration: none; cursor:default;color:black;" href = "detail208.php?idR=<?php echo "$ruangan"; ?>&idI=<?php echo $nomor[$nomor1];?>" >
                          <div class="b1">#<?php echo $nomor[$nomor1]; $nomor1++; ?></div></a></td>
                        <td width="11.25%"></td>
                        <td width="11.25%">
                          <a style="text-decoration: none; cursor:default;color:black;" href = "detail208.php?idR=<?php echo "$ruangan"; ?>&idI=<?php echo $nomor[$nomor1];?>" >
                          <div class="b3">#<?php echo $nomor[$nomor1]; $nomor1++; ?></div></a></td>
                      </tr>
                      <tr align = "center">
                      <td width="11.25%">
                          <a style="text-decoration: none; cursor:default;color:black;" href = "detail208.php?idR=<?php echo "$ruangan"; ?>&idI=<?php echo $nomor[$nomor1];?>" >
                          <div class="b3">#<?php echo $nomor[$nomor1]; $nomor1++; ?></div></a></td>
                        <td width="11.25%"></td>
                        <td width="11.25%">
                          <a style="text-decoration: none; cursor:default;color:black;" href = "detail208.php?idR=<?php echo "$ruangan"; ?>&idI=<?php echo $nomor[$nomor1];?>" >
                          <div class="b1">#<?php echo $nomor[$nomor1]; $nomor1++; ?></div></a></td>
                          <td width="11.25%">
                          <a style="text-decoration: none; cursor:default;color:black;" href = "detail208.php?idR=<?php echo "$ruangan"; ?>&idI=<?php echo $nomor[$nomor1];?>" >
                          <div class="b1">#<?php echo $nomor[$nomor1]; $nomor1++; ?></div></a></td>
                          <td width="11.25%">
                          <a style="text-decoration: none; cursor:default;color:black;" href = "detail208.php?idR=<?php echo "$ruangan"; ?>&idI=<?php echo $nomor[$nomor1];?>" >
                          <div class="b1">#<?php echo $nomor[$nomor1]; $nomor1++; ?></div></a></td>
                          <td width="11.25%">
                          <a style="text-decoration: none; cursor:default;color:black;" href = "detail208.php?idR=<?php echo "$ruangan"; ?>&idI=<?php echo $nomor[$nomor1];?>" >
                          <div class="b1">#<?php echo $nomor[$nomor1]; $nomor1++; ?></div></a></td>
                        <td width="11.25%"></td>
                        <td width="11.25%">
                          <a style="text-decoration: none; cursor:default;color:black;" href = "detail208.php?idR=<?php echo "$ruangan"; ?>&idI=<?php echo $nomor[$nomor1];?>" >
                          <div class="b3">#<?php echo $nomor[$nomor1]; $nomor1++; ?></div></a></td>
                      </tr>
                      <tr align = "center">
                      <td width="11.25%">
                          <a style="text-decoration: none; cursor:default;color:black;" href = "detail208.php?idR=<?php echo "$ruangan"; ?>&idI=<?php echo $nomor[$nomor1];?>" >
                          <div class="b3">#<?php echo $nomor[$nomor1]; $nomor1++; ?></div></a></td>
                        <td width="11.25%">
                          <a style="text-decoration: none; cursor:default;color:black;" href = "detail208.php?idR=<?php echo "$ruangan"; ?>&idI=<?php echo $nomor[$nomor1];?>" >
                          <div class="b1">#<?php echo $nomor[$nomor1]; $nomor1++; ?></div></a></td>
                          <td width="11.25%">
                          <a style="text-decoration: none; cursor:default;color:black;" href = "detail208.php?idR=<?php echo "$ruangan"; ?>&idI=<?php echo $nomor[$nomor1];?>" >
                          <div class="b1">#<?php echo $nomor[$nomor1]; $nomor1++; ?></div></a></td>
                          <td width="11.25%">
                          <a style="text-decoration: none; cursor:default;color:black;" href = "detail208.php?idR=<?php echo "$ruangan"; ?>&idI=<?php echo $nomor[$nomor1];?>" >
                          <div class="b1">#<?php echo $nomor[$nomor1]; $nomor1++; ?></div></a></td>
                          <td width="11.25%">
                          <a style="text-decoration: none; cursor:default;color:black;" href = "detail208.php?idR=<?php echo "$ruangan"; ?>&idI=<?php echo $nomor[$nomor1];?>" >
                          <div class="b1">#<?php echo $nomor[$nomor1]; $nomor1++; ?></div></a></td>
                          <td width="11.25%">
                          <a style="text-decoration: none; cursor:default;color:black;" href = "detail208.php?idR=<?php echo "$ruangan"; ?>&idI=<?php echo $nomor[$nomor1];?>" >
                          <div class="b1">#<?php echo $nomor[$nomor1]; $nomor1++; ?></div></a></td>
                          <td width="11.25%">
                          <a style="text-decoration: none; cursor:default;color:black;" href = "detail208.php?idR=<?php echo "$ruangan"; ?>&idI=<?php echo $nomor[$nomor1];?>" >
                          <div class="b1">#<?php echo $nomor[$nomor1]; $nomor1++; ?></div></a></td>
                          <td width="11.25%">
                          <a style="text-decoration: none; cursor:default;color:black;" href = "detail208.php?idR=<?php echo "$ruangan"; ?>&idI=<?php echo $nomor[$nomor1];?>" >
                          <div class="b3">#<?php echo $nomor[$nomor1]; $nomor1++; ?></div></a></td>
                      </tr>
                      <tr align = "center">
                      <td width="11.25%">
                          <a style="text-decoration: none; cursor:default;color:black;" href = "detail208.php?idR=<?php echo "$ruangan"; ?>&idI=<?php echo $nomor[$nomor1];?>" >
                          <div class="b3">#<?php echo $nomor[$nomor1]; $nomor1++; ?></div></a></td>
                        <td width="11.25%"></td>
                        <td width="11.25%"></td>
                        <td width="11.25%"></td>
                        <td width="11.25%"></td>
                        <td width="11.25%"></td>
                        <td width="11.25%"></td>
                        <td width="11.25%">
                          <a style="text-decoration: none; cursor:default;color:black;" href = "detail208.php?idR=<?php echo "$ruangan"; ?>&idI=<?php echo $nomor[$nomor1];?>" >
                          <div class="b3">#<?php echo $nomor[$nomor1]; $nomor1++; ?></div></a></td>
                      </tr>
                    </table>
                    </center>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
        <footer class="footer">
          <div class="container-fluid clearfix">
            <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright © 2018
              <a href="http://www.bootstrapdash.com/" target="_blank">Bootstrapdash</a>. All rights reserved.</span>
              <span class="float-none float-sm-right  mt-1 mt-sm-0 text-center" style ="color: #000f99;">
                <b>SISTECH UPH</b>
              </span>
          </div>
        </footer>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- plugins:js -->
  <script src="vendors/js/vendor.bundle.base.js"></script>
  <script src="vendors/js/vendor.bundle.addons.js"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="js/off-canvas.js"></script>
  <script src="js/misc.js"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="js/dashboard.js"></script>
  <!-- End custom js for this page-->
</body>

</html>