<!DOCTYPE html>
<html lang="en">
<?php
SESSION_START();
$idsaya = $_SESSION['myid'];
include('../../connect.php');
?>
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Inventory LAB Systems</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="vendors/iconfonts/mdi/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="vendors/css/vendor.bundle.base.css">
  <link rel="stylesheet" href="vendors/css/vendor.bundle.addons.css">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="css/style.css">
  <!-- endinject -->
  <link rel="icon" href="../img/logo2.png" type="image/x-icon"/>
</head>

<body>
   <?php
     include('split/head.php');

     include('split/left.php');
    ?>

    <?php
    $tangkap_id_ruangan = $_GET['id'];
    $query = mysqli_query($koneksi,"SELECT * from ruangan where id_ruangan='$tangkap_id_ruangan' ");
    $data = mysqli_fetch_array($query);
    ?>
    
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-lg-12 grid-margin">
              <div class="card">
                <div class="card-body"> 
                  <h4 class="card-title">Form Edit Ruangan</h4>

                    <form class="forms-sample" method="POST">
                      <input type="hidden" name="idruangan" value="<?php echo $tangkap_id_ruangan;?>" />
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Nama Ruangan</label>
                          <div class="col-sm-9">
                             <input type="text" class="form-control" id="editruangan" name="namaruangan" value="<?php echo $data['nama_ruangan'];?>" required="required">
                          </div>
                        </div>
                        <button type="submit" class="btn btn-success mr-2" name="submit">Submit</button>
                        <a href="ruangan.php"><button class="btn btn-light">Cancel</button></a>
                    </form>
                    <?php
                      if(isset($_POST['submit']))
                      {
                        include('../../connect.php');
                        $idsaya = $_SESSION['myid'];
                        $id_ruangan = $_POST['idruangan'];
                        $nama_ruangan = $_POST['namaruangan'];

                        $query = mysqli_query($koneksi, "UPDATE ruangan SET nama_ruangan ='$nama_ruangan', user_edit='$idsaya',waktu_edit=NOW() WHERE id_ruangan='$tangkap_id_ruangan'");
                      }
                    ?>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
        <footer class="footer">
          <div class="container-fluid clearfix">
            <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright © 2018
              <a href="http://www.bootstrapdash.com/" target="_blank">Bootstrapdash</a>. All rights reserved.</span>
            <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Hand-crafted & made with
              <i class="mdi mdi-heart text-danger"></i>
            </span>
          </div>
        </footer>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- plugins:js -->
  <script src="vendors/js/vendor.bundle.base.js"></script>
  <script src="vendors/js/vendor.bundle.addons.js"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="js/off-canvas.js"></script>
  <script src="js/misc.js"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="js/dashboard.js"></script>
  <!-- End custom js for this page-->
</body>

</html>