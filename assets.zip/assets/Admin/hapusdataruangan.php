<?php

	include('../../connect.php');

	SESSION_START();
	$idsaya = $_SESSION['myid'];
	$tangkap_id_ruangan = $_GET['id'];
	$status_delete = "0";
	
	$query = mysqli_query($koneksi, 
	"UPDATE ruangan 
	SET 
	user_delete='$idsaya',
	waktu_delete=NOW(),status_delete='$status_delete' 
	WHERE
	id_ruangan ='$tangkap_id_ruangan'");

	if(!$query)
	{
		echo "Gagal Simpan Data";
	}
	header('location:ruangan.php');
?>