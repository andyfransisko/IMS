<!DOCTYPE html>
<html lang="en">
<?php
SESSION_START();
$idsaya = $_SESSION['myid'];
include('../../connect.php');
?>
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Inventory LAB Systems</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="vendors/iconfonts/mdi/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="vendors/css/vendor.bundle.base.css">
  <link rel="stylesheet" href="vendors/css/vendor.bundle.addons.css">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="css/style.css">
  <!-- endinject -->
  <link rel="icon" href="../img/logo2.png" type="image/x-icon"/>
</head>

<body>
   <?php
     include('split/head.php');

     include('split/left.php');
    ?>

    <?php
    $query = mysqli_query($koneksi,"SELECT * from pengguna where id_pengguna='$idsaya' ");
    $data = mysqli_fetch_array($query);
    ?>
    
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-lg-12 grid-margin">
              <div class="card">
                <div class="card-body"> 
                  <h4 class="card-title">Form Change Password</h4>

                    <form class="forms-sample" method="POST">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Kata Sandi</label>
                          <div class="col-sm-9">
                             <input type="text" class="form-control" id="katasandi" name="katasandi" value="<?php echo $data['kata_sandi'];?>" required="required">
                          </div>
                        </div>
                        <button type="submit" class="btn btn-success mr-2" name="submit">Submit</button>
                        <a href="dashboard.php"><button type="button" class="btn btn-light">Cancel</button></a>
                    </form>
                    <?php
                      if(isset($_POST['submit']))
                      {
                        include('../../connect.php');
                        $idsaya = $_SESSION['myid'];
                        $kata_sandi = $_POST['katasandi'];

                        $query = mysqli_query($koneksi, "UPDATE pengguna SET kata_sandi ='$kata_sandi' WHERE id_pengguna='$idsaya'");

                        echo "<script type='text/javascript'>window.top.location='dashboard.php';</script>"; exit;
                      }
                    ?>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
        <footer class="footer">
          <div class="container-fluid clearfix">
            <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright © 2018
              <a href="http://www.bootstrapdash.com/" target="_blank">Bootstrapdash</a>. All rights reserved.</span>
              <span class="float-none float-sm-right  mt-1 mt-sm-0 text-center" style ="color: #000f99;">
                <b>SISTECH UPH</b>
              </span>
            </span>
          </div>
        </footer>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- plugins:js -->
  <script src="vendors/js/vendor.bundle.base.js"></script>
  <script src="vendors/js/vendor.bundle.addons.js"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="js/off-canvas.js"></script>
  <script src="js/misc.js"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="js/dashboard.js"></script>
  <!-- End custom js for this page-->
</body>

</html>