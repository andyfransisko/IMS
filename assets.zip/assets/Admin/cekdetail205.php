<!DOCTYPE html>
<html lang="en">

<head>
<?php
include('../../connect.php');

session_start();
?>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Inventory LAB Systems</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="vendors/iconfonts/mdi/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="vendors/css/vendor.bundle.base.css">
  <link rel="stylesheet" href="vendors/css/vendor.bundle.addons.css">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/style2.css">
  <!-- endinject -->
  <link rel="icon" href="../img/logo2.png" type="image/x-icon"/>

</head>

<body>
<?php
      session_start();

      $namasaya = $_SESSION['myname'];

      $idsaya = $_SESSION['myid'];

      $statussaya = $_SESSION['mystatus'];

      if(!isset($namasaya))
      {
        header('location:../../index.php');
      }
     
      
    /* Untuk Super Admin */
     if($statussaya == "Super Admin")
     {
        include('split/head.php');
      include('split/left.php');
     }

     /* Untuk Admin */
     else if($statussaya == "Admin")
     {
        include('split/head3.php');
      include('split/left3.php');
      
     }

    ?>
    
      <div class="main-panel">
        <div class="content-wrapper">
  
         <?php
          include('../../connect.php');
          $tangkap_idR = $_GET['idR'] ? $_GET['idR'] : null;
          $tangkap_idI = $_GET['idI'] ? $_GET['idI'] : null;
         ?>
          <div class="row">
            <div class="col-12 grid-margin">
              <div class="card">
                <div class="card-body">
                  <a href = "cek205.php"  >
                    <button type="button" class="btn btn-primary btn-rounded btn-fw float-left ">BACK</button><br>
                  </a>
                  
                  <br>
                  
                  <center><h1>Layout <?php echo $tangkap_idI ?></h1></center>
                  <div class="fluid-container">
                    <center>
                        
                     <?php

                /* SET default jenis barang */  
              $IDJB11 = "JB100004"; /* Monitor */
              $IDJB12 = "JB100001"; /* CPU */
              $IDJB13 = "JB100002"; /* Keyboard */
              $IDJB14 = "JB100003"; /* Mouse */

              /* Select ID Barang Monitor */
              $queryAmbilIDBarangMonitor = mysqli_query($koneksi,
              "SELECT id_barang FROM barang
              WHERE id_ruangan = '$tangkap_idR'
              AND id_jenisBarang = '$IDJB11'
              AND index_barang = '$tangkap_idI'");
              $IDMonitor1 = mysqli_fetch_assoc($queryAmbilIDBarangMonitor);
              $IDMonitor = $IDMonitor1['id_barang'];

              /* Select ID Barang CPU */
              /*
              $queryAmbilIDBarangMonitor = mysqli_query($koneksi,
              "SELECT id_barang FROM barang
              WHERE id_ruangan = '$tangkap_idR'
              AND id_jenisBarang = '$IDJB12'
              AND index_barang = '$tangkap_idI'");
              $IDCPU1 = mysqli_fetch_assoc($queryAmbilIDBarangCPU);
              $IDCPU = $IDCPU1['id_barang'];
                */
              /* Select ID Barang Keyboard */
              $queryAmbilIDBarangKeyboard = mysqli_query($koneksi,
              "SELECT id_barang FROM barang
              WHERE id_ruangan = '$tangkap_idR'
              AND id_jenisBarang = '$IDJB13'
              AND index_barang = '$tangkap_idI'");
              $IDKeyboard1 = mysqli_fetch_assoc($queryAmbilIDBarangKeyboard);
              $IDKeyboard = $IDKeyboard1['id_barang'];

              /* Select ID Barang Mouse */
              $queryAmbilIDBarangMouse = mysqli_query($koneksi,
              "SELECT id_barang FROM barang
              WHERE id_ruangan = '$tangkap_idR'
              AND id_jenisBarang = '$IDJB14'
              AND index_barang = '$tangkap_idI'");
              $IDMouse1 = mysqli_fetch_assoc($queryAmbilIDBarangMouse);
              $IDMouse = $IDMouse1['id_barang'];

              /* Select Status Monitor */
              $queryAmbilData1 = mysqli_query($koneksi, 
              "SELECT statusBarang FROM status_barang 
               JOIN pengecekan ON
               status_barang.id_statusBarang = pengecekan.id_statusBarang
               JOIN barang ON
               barang.id_barang = pengecekan.id_barang
               JOIN jenis_barang ON
               barang.id_jenisBarang = jenis_barang.id_jenisBarang
               JOIN ruangan ON
               barang.id_ruangan = ruangan.id_ruangan
               
               WHERE ruangan.id_ruangan = '$tangkap_idR'
               AND jenis_barang.id_jenisBarang = '$IDJB11'
               AND barang.index_barang = '$tangkap_idI' 
               ORDER BY id_pengecekan DESC LIMIT 1" );
              $StatusBarang1 = mysqli_fetch_assoc($queryAmbilData1);
              $hasil1  = $StatusBarang1['statusBarang'];

              /* Select ID Status Monitor  */
              $queryID1 = mysqli_query($koneksi, 
              "SELECT id_statusBarang FROM status_barang 
               WHERE status_barang.statusBarang = '$hasil1' 
               " );
              $IDStatusBarang1 = mysqli_fetch_assoc($queryID1);
              $IDhasil1 = $IDStatusBarang1['id_statusBarang'];


              /* Select Status CPU */
              /*
              $queryAmbilData2 = mysqli_query($koneksi, 
              "SELECT statusBarang FROM status_barang 
               JOIN pengecekan ON
               status_barang.id_statusBarang = pengecekan.id_statusBarang
               JOIN barang ON
               barang.id_barang = pengecekan.id_barang
               JOIN jenis_barang ON
               barang.id_jenisBarang = jenis_barang.id_jenisBarang
               JOIN ruangan ON
               barang.id_ruangan = ruangan.id_ruangan
               
               WHERE ruangan.id_ruangan = '$tangkap_idR'
               AND jenis_barang.id_jenisBarang = '$IDJB12'
               AND barang.index_barang = '$tangkap_idI' " );
              $StatusBarang2 = mysqli_fetch_assoc($queryAmbilData2);
              $hasil2  = $StatusBarang2['statusBarang'];
                */
              /* Select ID Status CPU  */
              /*
              $queryID2 = mysqli_query($koneksi, 
              "SELECT id_statusBarang FROM status_barang 
               WHERE statusBarang = '$hasil2'" );
              $IDStatusBarang2 = mysqli_fetch_assoc($queryID2);
              $IDhasil2 = $IDStatusBarang2['id_statusBarang'];
                */
              /* Select Status Keyboard */
              $queryAmbilData3 = mysqli_query($koneksi, 
              "SELECT statusBarang FROM status_barang 
               JOIN pengecekan ON
               status_barang.id_statusBarang = pengecekan.id_statusBarang
               JOIN barang ON
               barang.id_barang = pengecekan.id_barang
               JOIN jenis_barang ON
               barang.id_jenisBarang = jenis_barang.id_jenisBarang
               JOIN ruangan ON
               barang.id_ruangan = ruangan.id_ruangan
               
               WHERE ruangan.id_ruangan = '$tangkap_idR'
               AND jenis_barang.id_jenisBarang = '$IDJB13'
               AND barang.index_barang = '$tangkap_idI' 
               ORDER BY id_pengecekan DESC LIMIT 1" );
              $StatusBarang3 = mysqli_fetch_assoc($queryAmbilData3);
              $hasil3  = $StatusBarang3['statusBarang'];

              /* Select ID Status Keyboard  */
              $queryID3 = mysqli_query($koneksi, 
              "SELECT id_statusBarang FROM status_barang 
               WHERE statusBarang = '$hasil3'" );
              $IDStatusBarang3 = mysqli_fetch_assoc($queryID3);
              $IDhasil3 = $IDStatusBarang3['id_statusBarang'];

              /* Select Status Mouse */
              $queryAmbilData4 = mysqli_query($koneksi, 
              "SELECT statusBarang FROM status_barang 
               JOIN pengecekan ON
               status_barang.id_statusBarang = pengecekan.id_statusBarang
               JOIN barang ON
               barang.id_barang = pengecekan.id_barang
               JOIN jenis_barang ON
               barang.id_jenisBarang = jenis_barang.id_jenisBarang
               JOIN ruangan ON
               barang.id_ruangan = ruangan.id_ruangan
               
               WHERE ruangan.id_ruangan = '$tangkap_idR'
               AND jenis_barang.id_jenisBarang = '$IDJB14'
               AND barang.index_barang = '$tangkap_idI' 
               ORDER BY id_pengecekan DESC LIMIT 1 " );
              $StatusBarang4 = mysqli_fetch_assoc($queryAmbilData4);
              $hasil4  = $StatusBarang4['statusBarang'];
            
              /* Select ID Status Mouse  */
              $queryID4 = mysqli_query($koneksi, 
              "SELECT id_statusBarang FROM status_barang 
               WHERE statusBarang = '$hasil4'" );
              $IDStatusBarang4 = mysqli_fetch_assoc($queryID4);
              $IDhasil4 = $IDStatusBarang4['id_statusBarang'];

            ?>
            <form method = "POST" >
            <div class="row">
                
                <div class="col-md-6"><div class="form-group row">
                <label class="col-sm-3 col-form-label"> Monitor : </label>
                    <div class="col-sm-9">
                        
                            <!-- Monitor Form -->
                            <select name="statusmonitor" class="form-control" >
                            <option>
                                - Choose Condition - 
                            </option>
                              <?php
                              $query_statusMonitor = mysqli_query($koneksi, "SELECT * FROM status_barang "); 
                              while($data = mysqli_fetch_array($query_statusMonitor))
                              {
                                ?>
                                <option value="<?php echo $data['id_statusBarang'];
                                 ?>"
                                 <?php 
                                 if($IDhasil1 == $data['id_statusBarang'])
                                 {
                                     echo "selected";
                                 }?>>
                                <?php echo $data['statusBarang']; ?>
                                </option>
                                <?php } ?>
                                
                            </select>
                            <?php
                            $queryAmbilMonitor1 = mysqli_query($koneksi, 
                            "SELECT id_pengguna FROM pengecekan
                             JOIN barang ON
                             pengecekan.id_barang = barang.id_barang
                             JOIN ruangan ON
                             barang.id_ruangan = ruangan.id_ruangan
                             JOIN jenis_barang ON
                             barang.id_jenisBarang = jenis_barang.id_jenisBarang
                             
                             WHERE ruangan.id_ruangan = '$tangkap_idR'
                             AND jenis_barang.id_jenisBarang = '$IDJB11'
                             AND barang.index_barang = '$tangkap_idI' " );
                            $Pengguna1 = mysqli_fetch_assoc($queryAmbilMonitor1);
                            $hasilMonitor1 = $Pengguna1['id_pengguna'];

                            /* Select Nama Lengkap untuk Last Check By */
                            $queryAmbilMonitor2 = mysqli_query($koneksi,
                            "SELECT nama_lengkap FROM pengguna
                            WHERE id_pengguna = '$hasilMonitor1'");
                            $namaPenggunaMonitor = mysqli_fetch_assoc($queryAmbilMonitor2);
                            $hasilNamaMonitor = $namaPenggunaMonitor['nama_lengkap'];

                            /* Select Tanggal untuk last check by */
                            $queryAmbilMonitor3 = mysqli_query($koneksi, 
                            "SELECT waktu_pengecekan FROM pengecekan
                             JOIN barang ON
                             pengecekan.id_barang = barang.id_barang
                             JOIN ruangan ON
                             barang.id_ruangan = ruangan.id_ruangan
                             JOIN jenis_barang ON
                             barang.id_jenisBarang = jenis_barang.id_jenisBarang
                             
                             
                             WHERE ruangan.id_ruangan = '$tangkap_idR'
                             AND jenis_barang.id_jenisBarang = '$IDJB11'
                             AND barang.index_barang = '$tangkap_idI'
                             ORDER BY id_pengecekan DESC LIMIT 1" );
                             $waktuCekMonitor = mysqli_fetch_assoc($queryAmbilMonitor3);
                             $hasilWaktuMonitor = $waktuCekMonitor['waktu_pengecekan'];

                            ?>
                            
                            <h6><b>Last Checked by : </b> <?php echo $hasilNamaMonitor . " " . $hasilWaktuMonitor; ?></h6>
                        </div>
                </div>
            </div>
            <div class="col-md-6"><div class="form-group row">
                <label class="col-sm-3 col-form-label"> Keyboard : </label>
                    <div class="col-sm-9">
                            <!-- Keyboard FORM -->
                            <select name="statuskeyboard" class="form-control" >
                            <option>
                                    - Choose Condition -
                                </option>
                              <?php
                              $query_statusMonitor = mysqli_query($koneksi, "SELECT * FROM status_barang"); 
                              while($data = mysqli_fetch_array($query_statusMonitor))
                              {
                                ?>
                                <option value="<?php echo $data['id_statusBarang']; ?>"
                                <?php 
                                 if($IDhasil3 == $data['id_statusBarang'])
                                 {
                                     echo "selected";
                                 }?>>
                                <?php echo $data['statusBarang']; ?>
                                </option>
                                <?php } ?>
                            </select>

                            <?php
                            $queryAmbilKeyboard1 = mysqli_query($koneksi, 
                            "SELECT id_pengguna FROM pengecekan
                             JOIN barang ON
                             pengecekan.id_barang = barang.id_barang
                             JOIN ruangan ON
                             barang.id_ruangan = ruangan.id_ruangan
                             JOIN jenis_barang ON
                             barang.id_jenisBarang = jenis_barang.id_jenisBarang
                             
                             WHERE ruangan.id_ruangan = '$tangkap_idR'
                             AND jenis_barang.id_jenisBarang = '$IDJB13'
                             AND barang.index_barang = '$tangkap_idI' " );
                            $Pengguna3 = mysqli_fetch_assoc($queryAmbilKeyboard1);
                            $hasilKeyboard1 = $Pengguna3['id_pengguna'];

                            /* Select Nama Lengkap untuk Last Check By */
                            $queryAmbilKeyboard2 = mysqli_query($koneksi,
                            "SELECT nama_lengkap FROM pengguna
                            WHERE id_pengguna = '$hasilKeyboard1'");
                            $namaPenggunaKeyboard = mysqli_fetch_assoc($queryAmbilKeyboard2);
                            $hasilNamaKeyboard = $namaPenggunaKeyboard['nama_lengkap'];

                            /* Select Tanggal untuk last check by */
                            $queryAmbilKey3 = mysqli_query($koneksi, 
                            "SELECT waktu_pengecekan FROM pengecekan
                             JOIN barang ON
                             pengecekan.id_barang = barang.id_barang
                             JOIN ruangan ON
                             barang.id_ruangan = ruangan.id_ruangan
                             JOIN jenis_barang ON
                             barang.id_jenisBarang = jenis_barang.id_jenisBarang
                             
                             
                             WHERE ruangan.id_ruangan = '$tangkap_idR'
                             AND jenis_barang.id_jenisBarang = '$IDJB13'
                             AND barang.index_barang = '$tangkap_idI'
                             ORDER BY id_pengecekan DESC LIMIT 1" );
                             $waktuCekKeyboard = mysqli_fetch_assoc($queryAmbilKey3);
                             $hasilWaktuKeyboard = $waktuCekKeyboard['waktu_pengecekan'];

                            ?>

                            <h6><b>Last Checked by</b> <?php echo $hasilNamaKeyboard . " " . $hasilWaktuKeyboard; ?> </h6>
                        </div>
                </div>
            </div>
            <div class="col-md-6"><div class="form-group row">
                <label class="col-sm-3 col-form-label"> Mouse : </label>
                    <div class="col-sm-9">
                            <!-- Mouse Form -->
                            <select name="statusmouse" class="form-control" >
                            <option>
                                    - Choose Condition -
                                </option>
                              <?php
                              $query_statusMonitor = mysqli_query($koneksi, "SELECT * FROM status_barang"); 
                              while($data = mysqli_fetch_array($query_statusMonitor))
                              {
                                ?>
                                <option value="<?php echo $data['id_statusBarang']; ?>"
                                <?php 
                                 if($IDhasil4 == $data['id_statusBarang'])
                                 {
                                     echo "selected";
                                 }?>>
                                <?php echo $data['statusBarang']; ?>
                                </option>
                                <?php } ?>
                            </select>

                            <?php
                            $queryAmbilMouse1 = mysqli_query($koneksi, 
                            "SELECT id_pengguna FROM pengecekan
                             JOIN barang ON
                             pengecekan.id_barang = barang.id_barang
                             JOIN ruangan ON
                             barang.id_ruangan = ruangan.id_ruangan
                             JOIN jenis_barang ON
                             barang.id_jenisBarang = jenis_barang.id_jenisBarang
                             
                             WHERE ruangan.id_ruangan = '$tangkap_idR'
                             AND jenis_barang.id_jenisBarang = '$IDJB14'
                             AND barang.index_barang = '$tangkap_idI' " );
                            $Pengguna4 = mysqli_fetch_assoc($queryAmbilMouse1);
                            $hasilMouse1 = $Pengguna4['id_pengguna'];

                            /* Select Nama Lengkap untuk Last Check By */
                            $queryAmbilMouse2 = mysqli_query($koneksi,
                            "SELECT nama_lengkap FROM pengguna
                            WHERE id_pengguna = '$hasilMouse1'");
                            $namaPenggunaMouse = mysqli_fetch_assoc($queryAmbilMouse2);
                            $hasilNamaMouse = $namaPenggunaMouse['nama_lengkap'];

                            /* Select Tanggal untuk last check by */
                            $queryAmbilMouse3 = mysqli_query($koneksi, 
                            "SELECT waktu_pengecekan FROM pengecekan
                             JOIN barang ON
                             pengecekan.id_barang = barang.id_barang
                             JOIN ruangan ON
                             barang.id_ruangan = ruangan.id_ruangan
                             JOIN jenis_barang ON
                             barang.id_jenisBarang = jenis_barang.id_jenisBarang
                             
                             
                             WHERE ruangan.id_ruangan = '$tangkap_idR'
                             AND jenis_barang.id_jenisBarang = '$IDJB14'
                             AND barang.index_barang = '$tangkap_idI'
                             ORDER BY id_pengecekan DESC LIMIT 1" );
                             $waktuCekMouse = mysqli_fetch_assoc($queryAmbilMouse3);
                             $hasilWaktuMouse = $waktuCekMouse['waktu_pengecekan'];

                            ?>

                            <h6><b>Last Checked by</b> <?php echo $hasilNamaMouse . " " . $hasilWaktuMouse; ?> </h6>
                        </div>
                </div>
            </div>
                
            </div>
            <button type="submit" class="btn btn-primary  mr-2" name="submit1">SUBMIT</button>                
            </form>

            <?php
                include('../../connect.php');
                if(isset($_POST['submit1']))
                {
                    $SMonitor = $_POST['statusmonitor'];
                    $SKeyboard = $_POST['statuskeyboard'];
                    $SMouse = $_POST['statusmouse'];

                    $idsaya = $_SESSION['myid'];

                    
                    $querycek = mysqli_query($koneksi, "SELECT * FROM pengecekan " );
                    $checkBaris = mysqli_num_rows($querycek);
                    $PK = 100001 + $checkBaris;
                    $PK2 = "CEK" . $PK;
                    $queryinsert2 = mysqli_query($koneksi,
                    "INSERT INTO pengecekan (`id_pengecekan`, `id_pengguna`, 
                    `waktu_pengecekan`, `id_statusBarang`, `id_barang`) 
                    VALUES 
                    ('$PK2', '$idsaya', NOW(), '$SMonitor', '$IDMonitor')");

                    $querycek = mysqli_query($koneksi, "SELECT * FROM pengecekan " );
                    $checkBaris = mysqli_num_rows($querycek);
                    $PK = 100001 + $checkBaris;
                    $PK3 = "CEK" . $PK;
                    $queryinsert2 = mysqli_query($koneksi,
                    "INSERT INTO pengecekan (`id_pengecekan`, `id_pengguna`, 
                    `waktu_pengecekan`, `id_statusBarang`, `id_barang`) 
                    VALUES 
                    ('$PK3', '$idsaya', NOW(), '$SMouse', '$IDMouse')");

                    $querycek = mysqli_query($koneksi, "SELECT * FROM pengecekan " );
                    $checkBaris = mysqli_num_rows($querycek);
                    $PK = 100001 + $checkBaris;
                    $PK4 = "CEK" . $PK;
                    $queryinsert2 = mysqli_query($koneksi,
                    "INSERT INTO pengecekan (`id_pengecekan`, `id_pengguna`, 
                    `waktu_pengecekan`, `id_statusBarang`, `id_barang`) 
                    VALUES 
                    ('$PK4', '$idsaya', NOW(), '$SKeyboard', '$IDKeyboard')");
                        
                        echo "<script type='text/javascript'>window.top.location='cek205.php';</script>"; exit;
                }
            ?>
                    
                    </center>
                    <br>
                    
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
        <footer class="footer">
          <div class="container-fluid clearfix">
            <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright © 2018
              <a href="http://www.bootstrapdash.com/" target="_blank">Bootstrapdash</a>. All rights reserved.</span>
              <span class="float-none float-sm-right  mt-1 mt-sm-0 text-center" style ="color: #000f99;">
                <b>SISTECH UPH</b>
              </span>
          </div>
        </footer>

        

        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- plugins:js -->
  <script src="vendors/js/vendor.bundle.base.js"></script>
  <script src="vendors/js/vendor.bundle.addons.js"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="js/off-canvas.js"></script>
  <script src="js/misc.js"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="js/dashboard.js"></script>
  <!-- End custom js for this page-->
</body>

</html>