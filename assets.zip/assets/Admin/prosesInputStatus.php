<?php
if(isset($_POST['submit']))
{
	include('../../connect.php');
	$nama_status = $_POST['namastatus'];
	$id_status = $_POST['idstatus'];
	SESSION_START();
	$idsaya = $_SESSION['myid'];

	$query = mysqli_query($koneksi, "INSERT INTO status 
	(id_status,nama_status,user_add,waktu_add,status_delete) 
	VALUES ('$id_status','$nama_status','$idsaya', NOW(),'1')");

	if(!$query)
	{
		echo "Gagal Simpan Data";
	}
	header('location:status.php');
	}
	else
	{
	header('location:status.php');
	}
?>