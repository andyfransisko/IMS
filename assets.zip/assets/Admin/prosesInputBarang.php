<?php
if(isset($_POST['submit']))
{
	include('../../connect.php');
	SESSION_START();
	$idsaya = $_SESSION['myid'];
	$id_barang = $_POST['idbarang'];
	$id_ruangan = $_POST['idruangan'];
	$id_jenisBarang = $_POST['idjenisbarang'];
	$nama_barang = $_POST['namabarang'];
	$merk_barang = $_POST['merkbarang'];
	$index_barang = $_POST['indexbarang'];
	$stok_barang = $_POST['stokbarang'];
	$tanggal_pembelian = $_POST['tanggalpembelian'];

	$query = mysqli_query($koneksi, "INSERT INTO barang 
	(id_barang,id_ruangan,id_jenisBarang,nama_barang,merk,index_barang,
	stok_barang,tanggal_beli,user_add,waktu_add,status_delete) 
	VALUES 
	('$id_barang','$id_ruangan','$id_jenisBarang',
	'$nama_barang','$merk_barang','$index_barang','$stok_barang','$tanggal_pembelian',
	'$idsaya', NOW(),'1')");

	if(!$query)
	{
		echo "Gagal Simpan Data";
	}
	header('location:barang.php');
}
else
{
	header('location:barang.php');
}
?>