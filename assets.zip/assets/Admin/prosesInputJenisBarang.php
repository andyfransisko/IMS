<?php
if(isset($_POST['submit']))
{
	include('../../connect.php');
	$nama_jenisBarang = $_POST['namajenisbarang'];
	$id_jenisBarang = $_POST['idjenisbarang'];

	
	SESSION_START();
	$idsaya = $_SESSION['myid'];

	$query = mysqli_query($koneksi, "INSERT INTO jenis_barang 
	(id_jenisBarang,nama_jenisBarang,user_add,waktu_add,status_delete) 
	VALUES 
	('$id_jenisBarang','$nama_jenisBarang','$idsaya',NOW(),'1')");

	if(!$query)
	{
		echo "Gagal Simpan Data";
	}
	header('location:jenisBarang.php');
	}
	else
	{
	header('location:jenisBarang.php');
	}
?>