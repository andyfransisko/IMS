<!DOCTYPE html>
<html lang="en">

<head>

  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Inventory LAB Systems</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="vendors/iconfonts/mdi/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="vendors/css/vendor.bundle.base.css">
  <link rel="stylesheet" href="vendors/css/vendor.bundle.addons.css">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="css/style.css">
  <!-- endinject -->
  <link rel="icon" href="../img/logo2.png" type="image/x-icon"/>
</head>

<body>
<?php
      session_start();

      $namasaya = $_SESSION['myname'];

      $idsaya = $_SESSION['myid'];

      $statussaya = $_SESSION['mystatus'];

      if(!isset($namasaya))
      {
        header('location:../../index.php');
      }
     
      
    /* Untuk Super Admin */
     if($statussaya == "Super Admin")
     {
      include('split/head.php');
      include('split/left.php');
     }

     /* Untuk Admin */
     else if($statussaya == "Admin")
     {
      include('split/head3.php');
      include('split/left3.php');
      
     }

     /* Untuk User */
     else if($statussaya == "User")
     {
      include('split/left5.php');
     }
    ?>
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-lg-12 grid-margin">
              <div class="card">
                <div class="card-body"><a href = "inputBarang.php"><button type="button" class="btn btn-primary btn-fw float-right "><i class="mdi mdi-plus"></i>INPUT</button></a>
                  <?php
                      /* Untuk Super Admin */
                       if($statussaya == "Super Admin")
                       {
                   ?> 
                  <a href = "printBarang.php"><button type="button" class="btn btn-info btn-fw float-right "><i class="mdi mdi-file-pdf-box"></i>PDF</button></a>
                  <form action="statusbarangexcel.php" method="POST">
                    <button type="submit" name="export_excel" class="btn btn-success btn-fw float-right"><i class="mdi mdi-file-excel-box"></i>EXCEL</button>
                  </form> 
                  <a href = "printBarang.php"><button type="button" class="btn btn-info btn-fw float-right "><i class="mdi mdi-file-pdf-box"></i>PDF</button></a>
                  <form action="statusbarangexcel.php" method="POST">
                    <button type="submit" name="export_excel" class="btn btn-success btn-fw float-right"><i class="mdi mdi-file-excel-box"></i>EXCEL</button>
                  </form>
                  <?php
                  }?>
                  <h4 class="card-title">Barang</h4>
                  <div class="table-responsive">
                    <table class="table table-striped">
                      <thead>
                        <tr align="center">
                          <th>
                            ID Barang
                          </th>
                          <th>
                            ID Ruangan
                          </th>
                          <th>
                            ID Jenis Barang
                          </th>
                          <th>
                            Nama Barang
                          </th>
                          <th>
                            Merk
                          </th>
                          <th>
                            Index Barang
                          </th>
                          <th>
                            Stok Barang
                          </th>
                          <th>
                            Tanggal Beli
                          </th>
                          <?php 
                          /* Untuk Super Admin */
                            if($statussaya == "Super Admin")
                            {
                              
                            ?>
                          <th>
                            Aksi
                          </th>
                          <?php
                            }
                            ?>
                        </tr>
                      </thead>
                      <tbody align="center">
                        <?php
                          include('../../connect.php');
                        ?>
                        <?php
                          $query = mysqli_query($koneksi,"SELECT * FROM barang WHERE status_delete='1'");
                          while($data = mysqli_fetch_array($query))
                          {
                        ?>
                        <tr>
                          <td><?php echo $data['id_barang'];?></td>
                          <td><?php echo $data['id_ruangan']?></td>
                          <td><?php echo $data['id_jenisBarang']?></td>
                          <td><?php echo $data['nama_barang'];?></td>
                          <td><?php echo $data['merk'];?></td>
                          <td><?php echo $data['index_barang'];?></td>
                          <td><?php echo $data['stok_barang'];?></td>
                          <td><?php echo $data['tanggal_beli'];?></td>
                          <?php 
                          /* Untuk Super Admin */
                            if($statussaya == "Super Admin")
                            {
                              
                            ?>
                          <td>

                            <a href="editdatabarang.php?id=<?php echo $data['id_barang'];?>"><button class="btn btn-sm btn-warning"><i class="glyphicon glyphicon-pencil"></i>Edit</button></a>

                            <a href="hapusdatabarang.php?id=<?php echo $data['id_barang'];?>"><button class="btn btn-sm btn-danger"><i class="glyphicon glyphicon-trash"></i>Delete</button></a>
                          </td>
                          <?php
                            }
                            ?>
                        </tr>
                        <?php
                        }  ?>
                      </tbody>
                      <tfoot>
                        <tr align="center">
                          <th>
                            ID Barang
                          </th>
                          <th>
                            ID Ruangan
                          </th>
                          <th>
                            ID Jenis Barang
                          </th>
                          <th>
                            Nama Barang
                          </th>
                          <th>
                            Merk
                          </th>
                          <th>
                            Index Barang
                          </th>
                          <th>
                            Stok Barang
                          </th>
                          <th>
                            Tanggal Beli
                          </th>
                          <?php 
                          /* Untuk Super Admin */
                            if($statussaya == "Super Admin")
                            {
                              
                            ?>
                          <th>
                            Aksi
                          </th>
                          <?php
                            }
                            ?>
                        </tr>
                      </tfoot>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
        <footer class="footer">
          <div class="container-fluid clearfix">
            <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright © 2018
              <a href="http://www.bootstrapdash.com/" target="_blank">Bootstrapdash</a>. All rights reserved.</span>
              <span class="float-none float-sm-right  mt-1 mt-sm-0 text-center" style ="color: #000f99;">
                <b>SISTECH UPH</b>
              </span>
            </span>
          </div>
        </footer>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- plugins:js -->
  <script src="vendors/js/vendor.bundle.base.js"></script>
  <script src="vendors/js/vendor.bundle.addons.js"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="js/off-canvas.js"></script>
  <script src="js/misc.js"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="js/dashboard.js"></script>
  <!-- End custom js for this page-->
</body>

</html>