<?php
if(isset($_POST['submit']))
{
	include('../../connect.php');
	$id_pengecekan = $_POST['idpengecekan'];
	$id_pengguna = $_POST['idpengguna'];
	$waktu_pengecekan = $_POST['waktupengecekan'];
	$id_statusBarang = $_POST['idstatusbarang'];
	$id_barang = $_POST['idbarang'];


	$query = mysqli_query($koneksi, "INSERT INTO pengecekan (id_pengecekan,id_pengguna,waktu_pengecekan,id_statusBarang,id_barang) VALUES ('$id_pengecekan','$id_pengguna','$waktu_pengecekan','$id_statusBarang','$id_barang')");

	if(!$query)
	{
		echo "Gagal Simpan Data";
	}
	header('location:pengecekan.php');
}
else
{
	header('location:pengecekan.php');
}
?>