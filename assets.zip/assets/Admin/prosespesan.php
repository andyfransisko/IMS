<?php
if(isset($_POST['submit']))
{
	include('../../connect.php');
	$tujuan = $_POST['namatujuan'];
    $topik = $_POST['topik'];
    $pesan = $_POST['pesan'];

	
	SESSION_START();
    $idsaya = $_SESSION['myid'];
    
    $query1 = mysqli_query($koneksi, "SELECT * FROM pesan " );

      $checkBaris = mysqli_num_rows($query1);
      $PKA = 100001 + $checkBaris;
      $PK1 = "P".$PKA;

      $query2 = mysqli_query($koneksi, "SELECT * FROM pesan_detail " );

      $checkBaris = mysqli_num_rows($query2);
      $PKB = 100001 + $checkBaris;
      $PK2 = "PD".$PKB;

	$query3 = mysqli_query($koneksi, "INSERT INTO 
    `pesan` (`id_pesan`, `id_penggunaKirimPesan`, `topik_pesan`) 
    VALUES 
    ('$PK1', '$idsaya', '$topik')");
    
    $query4 = mysqli_query($koneksi, "INSERT INTO 
    `pesan_detail` 
    (`id_pesanDetail`, `id_pesan`, `id_penggunaKe`, 
    `id_penggunaDari`, `tanggalWaktu`, `pesan`, `status_pesan`) 
    VALUES 
    ('$PK2', '$PK1', '$tujuan', '$idsaya', NOW(), 
    '$pesan', '1')");

	if(!$query4)
	{
		echo "Gagal Simpan Data";
	}
	header('location:dashboard.php');
	}
	else
	{
	header('location:dashboard.php');
	}
?>