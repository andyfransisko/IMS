<?php
include('../../connect.php');
$output='';
if(isset($_POST['export_excel']))
{
	$result = mysqli_query($koneksi , "SELECT * FROM pengguna");
	if(mysqli_num_rows($result) > 0)
	{
		$output .= '<table class="table" border="1">
		<tr>
			<th>
              ID Pengguna
            </th>
            <th>
              Email
            </th>
            <th>
              Kata Sandi
            </th>
            <th>
              Nama Lengkap
            </th>
            <th>
              Tanggal Lahir
            </th>
            <th>
              Alamat
            </th>
            <th>
              No HP
            </th>
            <th>
              Tanggal Masuk
            </th>
            <th>
              Status Pengguna
            </th>
          </tr>
         ';
         while($data = mysqli_fetch_array($result))
         {
         	$output.='
         	<tr>
         	<td>'.$data["id_pengguna"].'</td>
         	<td>'.$data["email"].'</td>
         	<td>'.$data["kata_sandi"].'</td>
         	<td>'.$data["nama_lengkap"].'</td>
         	<td>'.$data["tanggal_lahir"].'</td>
         	<td>'.$data["alamat"].'</td>
         	<td>'.$data["no_hp"].'</td>
         	<td>'.$data["tanggal_masuk"].'</td>
         	<td>'.$data["status_pengguna"].'</td>
         	</tr>
         	';
         }
                  $output .= '</table>';
         header("Content-Type: application/xls");
         header("Content-Disposition:attachment; filename=pengguna.xls");
         echo $output;
	}
}
?>