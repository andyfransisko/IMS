<?php
include('../../connect.php');
$tangkap_id_laporan = $_GET['id'];

$query = mysqli_query($koneksi,"DELETE from laporan where id_laporan ='$tangkap_id_laporan'");

if($query){
  header('location:laporan.php');
}
?>