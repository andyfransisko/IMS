<?php
include('../../connect.php');
$tangkap_id_pengecekan = $_GET['id'];

$query = mysqli_query($koneksi,"DELETE from pengecekan where id_pengecekan ='$tangkap_id_pengecekan'");

if($query){
  header('location:pengecekan.php');
}
?>