<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Inventory LAB Systems</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="vendors/iconfonts/mdi/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="vendors/css/vendor.bundle.base.css">
  <link rel="stylesheet" href="vendors/css/vendor.bundle.addons.css">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="css/style.css">
  <!-- endinject -->
  <link rel="icon" href="../img/logo2.png" type="image/x-icon"/>
</head>

<body>
   <?php
     include('split/head.php');

     include('split/left.php');
    ?>
    
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-lg-12 grid-margin">
              <div class="card">
                <div class="card-body"><a href = "inputStatus.php"><button type="button" class="btn btn-primary btn-fw float-right "><i class="mdi mdi-plus"></i>INPUT</button></a>
                  <a href = "printStatus.php"><button type="button" class="btn btn-info btn-fw float-right "><i class="mdi mdi-file-pdf-box"></i>PDF</button></a>
                  <form action="statusexcel.php" method="POST">
                    <button type="submit" name="export_excel" class="btn btn-success btn-fw float-right"><i class="mdi mdi-file-excel-box"></i>EXCEL</button>
                  </form>
                  <h4 class="card-title">Status</h4>
                  <div class="table-responsive">
                    <table class="table table-striped">
                      <thead>
                        <tr align="center">
                          <th>
                            ID Status
                          </th>
                          <th>
                            Nama Status
                          </th>
                          <th>
                            Aksi
                          </th>
                        </tr>
                      </thead>
                      <tbody align="center">
                        <?php
                          include('../../connect.php');
                        ?>
                        <?php
                          $query = mysqli_query($koneksi,"SELECT * FROM status WHERE status_delete='1'");
                          while($data = mysqli_fetch_array($query))
                          {
                        ?>
                        <tr>
                          <td><?php echo $data['id_status'];?></td>
                          <td><?php echo $data['nama_status'];?></td>
                          <td>
                            

                            <a href="editdatastatus.php?id=<?php echo $data['id_status'];?>"><button class="btn btn-sm btn-warning"><i class="glyphicon glyphicon-pencil"></i>Edit</button></a>

                            <a href="hapusdatastatus.php?id=<?php echo $data['id_status'];?>"><button class="btn btn-sm btn-danger"><i class="glyphicon glyphicon-trash"></i>Delete</button></a>
                          </td>
                        </tr>
                        <?php
                        }  ?>
                      </tbody>
                      <tfoot>
                        <tr align="center">
                          <th>
                            ID Status
                          </th>
                          <th>
                            Nama Status
                          </th>
                          <th>
                            Aksi
                          </th>
                        </tr>
                      </tfoot>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
        <footer class="footer">
          <div class="container-fluid clearfix">
            <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright © 2018
              <a href="http://www.bootstrapdash.com/" target="_blank">Bootstrapdash</a>. All rights reserved.</span>
              <span class="float-none float-sm-right  mt-1 mt-sm-0 text-center" style ="color: #000f99;">
                <b>SISTECH UPH</b>
              </span>
          </div>
        </footer>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- plugins:js -->
  <script src="vendors/js/vendor.bundle.base.js"></script>
  <script src="vendors/js/vendor.bundle.addons.js"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="js/off-canvas.js"></script>
  <script src="js/misc.js"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="js/dashboard.js"></script>
  <!-- End custom js for this page-->
</body>

</html>