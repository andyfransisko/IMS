<?php
include('../../connect.php');
$output='';
if(isset($_POST['export_excel']))
{
   $result = mysqli_query($koneksi , "SELECT * FROM status");
   if(mysqli_num_rows($result) > 0)
   {
      $output .= '<table class="table" border="1">
      <tr>
         <th>
            ID Status
         </th>
         <th>
            Nama Status
          </th>
          </tr>
         ';
         while($data = mysqli_fetch_array($result))
         {
            $output.='
            <tr>
            <td>'.$data["id_status"].'</td>
            <td>'.$data["nama_status"].'</td>
            </tr>
            ';
         }
                  $output .= '</table>';
         header("Content-Type: application/xls");
         header("Content-Disposition:attachment; filename=status.xls");
         echo $output;
   }
}
?>