<?php
include('../../connect.php');
$output='';
if(isset($_POST['export_excel']))
{
	$result = mysqli_query($koneksi , "SELECT * FROM barang");
	if(mysqli_num_rows($result) > 0)
	{
		$output .= '<table class="table" border="1">
		<tr>
			<th>
              ID Barang
            </th>
            <th>
              ID Ruangan
            </th>
            <th>
              ID Jenis Barang
            </th>
            <th>
              Nama Barang
            </th>
            <th>
              Merk
            </th>
            <th>
              Index Barang
            </th>
            <th>
              Stok Barang
            </th>
            <th>
              Tanggal Beli
            </th>
          </tr>
         ';
         while($data = mysqli_fetch_array($result))
         {
         	$output.='
         	<tr>
         	<td>'.$data["id_barang"].'</td>
         	<td>'.$data["id_ruangan"].'</td>
          <td>'.$data["id_jenisBarang"].'</td>
         	<td>'.$data["nama_barang"].'</td>
         	<td>'.$data["merk"].'</td>
         	<td>'.$data["index_barang"].'</td>
         	<td>'.$data["stok_barang"].'</td>
         	<td>'.$data["tanggal_beli"].'</td>
         	</tr>
         	';
         }
                  $output .= '</table>';
         header("Content-Type: application/xls");
         header("Content-Disposition:attachment; filename=barang.xls");
         echo $output;
	}
}
?>