<?php
include('../../connect.php');
$output='';
if(isset($_POST['export_excel']))
{
	$result = mysqli_query($koneksi , "SELECT * FROM detail_pengguna");
	if(mysqli_num_rows($result) > 0)
	{
		$output .= '<table class="table" border="1">
		<tr>
			<th>
            ID Detail Pengguna
            </th>
            <th>
              ID Pengguna
            </th>
            <th>
              ID Status
            </th>
          </tr>
         ';
         while($data = mysqli_fetch_array($result))
         {
         	$output.='
         	<tr>
         	<td>'.$data["id_detailPengguna"].'</td>
         	<td>'.$data["id_pengguna"].'</td>
            <td>'.$data["id_status"].'</td>
         	</tr>
         	';
         }
                  $output .= '</table>';
         header("Content-Type: application/xls");
         header("Content-Disposition:attachment; filename=detailPengguna.xls");
         echo $output;
	}
}
?>