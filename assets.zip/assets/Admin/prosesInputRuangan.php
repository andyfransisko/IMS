<?php
if(isset($_POST['submit']))
{

	include('../../connect.php');


	SESSION_START();
	$idsaya = $_SESSION['myid'];

	$nama_ruangan = $_POST['namaruangan'];
	$id_ruangan = $_POST['idruangan'];

	$query = mysqli_query($koneksi, 
	"INSERT INTO ruangan 
	(id_ruangan,nama_ruangan,user_add,waktu_add,status_delete) 
	VALUES ('$id_ruangan','$nama_ruangan','$idsaya', NOW(),'1')");

	if(!$query)
	{
		echo "Gagal Simpan Data";
	}
	header('location:ruangan.php');
	}
	else
	{
	header('location:ruangan.php');
	}
?>