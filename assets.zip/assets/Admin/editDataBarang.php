<!DOCTYPE html>
<html lang="en">
<?php
SESSION_START();
$idsaya = $_SESSION['myid'];
include('../../connect.php');
?>
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Inventory LAB Systems</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="vendors/iconfonts/mdi/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="vendors/css/vendor.bundle.base.css">
  <link rel="stylesheet" href="vendors/css/vendor.bundle.addons.css">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="css/style.css">
  <!-- endinject -->
  <link rel="icon" href="../img/logo2.png" type="image/x-icon"/>
</head>

<body>
   <?php
     include('split/head.php');

     include('split/left.php');
    ?>

    <?php
    $tangkap_id_barang = $_GET['id'];
    $query = mysqli_query($koneksi,
    "SELECT b.id_barang, r.id_ruangan, j.id_jenisBarang, 
    b.nama_barang, b.merk, b.stok_barang, b.tanggal_beli,b.index_barang
    FROM 
    barang b JOIN jenis_barang j JOIN ruangan r  
    ON b.id_ruangan = r.id_ruangan 
    AND b.id_jenisBarang = j.id_jenisBarang WHERE 
    b.id_barang='$tangkap_id_barang'");

    $data = mysqli_fetch_array($query);
    ?>
    
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-lg-12 grid-margin">
              <div class="card">
                <div class="card-body"> 
                  <h4 class="card-title">Form Edit Barang</h4>

                    <form class="forms-sample" method="POST">
                    <div class="form-group row">
                          <label class="col-sm-3 col-form-label">ID Barang</label>
                          <div class="col-sm-9">
                            <input type="Text" class="form-control" name="idbarang" id="PKB" placeholder="ID Barang" readonly
                            value="<?php
                              echo $tangkap_id_barang;
                            ?>" readonly>
                          </div>
                        </div>
                      <input type="hidden" name="idbarang" value="<?php echo $tangkap_id_barang;?>" />
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">ID Ruangan</label>
                          <div class="col-sm-9">
                             <input type="text" class="form-control" id="editbarang" name="idruangan" value="<?php echo $data['id_ruangan'];?>" readonly>
                          </div>
                        </div>
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">ID Jenis Barang</label>
                          <div class="col-sm-9">
                             <input type="text" class="form-control" id="editbarang" name="idjenisbarang" value="<?php echo $data['id_jenisBarang'];?>" readonly>
                          </div>
                        </div>
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Nama Barang</label>
                          <div class="col-sm-9">
                             <input type="text" class="form-control" id="editbarang" name="namabarang" value="<?php echo $data['nama_barang'];?>" required="required">
                          </div>
                        </div>
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Merk</label>
                          <div class="col-sm-9">
                             <input type="text" class="form-control" id="editbarang" name="merk" value="<?php echo $data['merk'];?>" required="required">
                          </div>
                        </div>
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Index Barang</label>
                          <div class="col-sm-9">
                             <input type="number" class="form-control" id="editbarang" name="indexbarang" value="<?php echo $data['index_barang'];?>" required="required">
                          </div>
                        </div>
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Stok Barang</label>
                          <div class="col-sm-9">
                             <input type="number" class="form-control" id="editbarang" name="stokbarang" value="<?php echo $data['stok_barang'];?>" required="required">
                          </div>
                        </div>
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Tanggal Beli</label>
                          <div class="col-sm-9">
                             <input type="date" class="form-control" id="editbarang" name="tanggalbeli" value="<?php echo $data['tanggal_beli'];?>" required="required">
                          </div>
                        </div>
                        <button type="submit" class="btn btn-success mr-2" name="submit">Submit</button>
                        <a href="barang.php"><button type="button" class="btn btn-light">Cancel</button></a>
                    </form>
                    <?php
                      if(isset($_POST['submit']))
                      {
                        include('../../connect.php');
                        $idsaya = $_SESSION['myid'];
                        $id_barang = $_POST['idbarang'];
                        $nama_barang = $_POST['namabarang'];
                        $merk = $_POST['merk'];

                        $index_barang = $_POST['indexbarang'];
                        $stok_barang = $_POST['stokbarang'];
                        $tanggal_beli = $_POST['tanggalbeli'];

                        $query = mysqli_query($koneksi, "UPDATE barang SET nama_barang ='$nama_barang',merk='$merk',index_barang='$index_barang',stok_barang='$stok_barang',tanggal_beli='$tanggal_beli', user_edit='$idsaya',waktu_edit=NOW() WHERE id_barang='$tangkap_id_barang'");
                        echo "<script type='text/javascript'>window.top.location='barang.php';</script>"; exit;
                      }
                    ?>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
        <footer class="footer">
          <div class="container-fluid clearfix">
            <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright © 2018
              <a href="http://www.bootstrapdash.com/" target="_blank">Bootstrapdash</a>. All rights reserved.</span>
              <span class="float-none float-sm-right  mt-1 mt-sm-0 text-center" style ="color: #000f99;">
                <b>SISTECH UPH</b>
              </span>
          </div>
        </footer>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- plugins:js -->
  <script src="vendors/js/vendor.bundle.base.js"></script>
  <script src="vendors/js/vendor.bundle.addons.js"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="js/off-canvas.js"></script>
  <script src="js/misc.js"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="js/dashboard.js"></script>
  <!-- End custom js for this page-->
</body>

</html>