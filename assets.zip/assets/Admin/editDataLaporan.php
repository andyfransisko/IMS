<!DOCTYPE html>
<html lang="en">
<?php
SESSION_START();
$idsaya = $_SESSION['myid'];
include('../../connect.php');
?>
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Inventory LAB Systems</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="vendors/iconfonts/mdi/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="vendors/css/vendor.bundle.base.css">
  <link rel="stylesheet" href="vendors/css/vendor.bundle.addons.css">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="css/style.css">
  <!-- endinject -->
  <link rel="icon" href="../img/logo2.png" type="image/x-icon"/>
</head>

<body>
   <?php
     include('split/head.php');

     include('split/left.php');
    ?>

    <?php
    $tangkap_id_laporan = $_GET['id'];
    $query = mysqli_query($koneksi,"SELECT * from laporan JOIN pengguna ON pengguna.id_pengguna=laporan.id_pengguna JOIN jenis_barang ON jenis_barang.id_jenisBarang=laporan.id_jenisBarang JOIN status_barang ON status_barang.id_statusBarang=laporan.id_statusBarang JOIN ruangan ON ruangan.id_ruangan=laporan.id_ruangan WHERE id_laporan='$tangkap_id_laporan'");
    $data = mysqli_fetch_array($query);
    ?>
    
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-lg-12 grid-margin">
              <div class="card">
                <div class="card-body"> 
                  <h4 class="card-title">Form Edit Ruangan</h4>

                    <form class="forms-sample" method="POST">
                      <input type="hidden" name="idlaporan" value="<?php echo $tangkap_id_laporan;?>" />
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">ID Pengguna</label>
                          <div class="col-sm-9">
                             <input type="text" class="form-control" id="editlaporan" name="idpengguna" value="<?php echo $data['id_pengguna'];?>" readonly>
                          </div>
                        </div>
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Waktu Laporan</label>
                          <div class="col-sm-9">
                             <input type="datetime" class="form-control" id="editbarang" name="waktu_laporan" value="<?php echo $data['waktu_laporan'];?>" required="required">
                          </div>
                        </div>
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">ID Ruangan</label>
                          <div class="col-sm-9">
                             <input type="text" class="form-control" id="editlaporan" name="idruangan" value="<?php echo $data['id_ruangan'];?>" readonly>
                          </div>
                        </div>
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Index Barang</label>
                          <div class="col-sm-9">
                             <input type="text" class="form-control" id="editlaporan" name="indexbarang" value="<?php echo $data['index_barang'];?>" required="required">
                          </div>
                        </div>
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">ID Jenis Barang</label>
                          <div class="col-sm-9">
                             <input type="text" class="form-control" id="editlaporan" name="idjenisbarang" value="<?php echo $data['id_jenisBarang'];?>" readonly>
                          </div>
                        </div>
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">ID Status Barang</label>
                          <div class="col-sm-9">
                             <input type="text" class="form-control" id="editlaporan" name="idstatusbarang" value="<?php echo $data['id_statusBarang'];?>" readonly>
                          </div>
                        </div>
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Keterangan</label>
                          <div class="col-sm-9">
                             <input type="text" class="form-control" id="editlaporan" name="keterangan" value="<?php echo $data['keterangan'];?>" required="required">
                          </div>
                        </div>

                        <button type="submit" class="btn btn-success mr-2" name="submit">Submit</button>
                        <a href="ruangan.php"><button class="btn btn-light">Cancel</button></a>
                    </form>
                    <?php
                      if(isset($_POST['submit']))
                      {
                        include('../../connect.php');
                        $id_laporan = $_POST['idlaporan'];
                        $id_pengguna = $_POST['idpengguna'];
                        $waktu_laporan = $_POST['idlaporan'];
                        $id_ruangan = $_POST['idruangan'];
                        $index_barang = $_POST['indexbarang'];
                        $id_jenisBarang = $_POST['idjenisbarang'];
                        $id_statusBarang = $_POST['idstatusbarang'];
                        $keterangan = $_POST['keterangan'];
                        $query = mysqli_query($koneksi, "UPDATE laporan SET id_pengguna ='$id_pengguna', waktu_laporan ='$waktu_laporan', id_ruangan ='$id_ruangan', index_barang ='$index_barang', id_jenisBarang ='$id_jenisBarang', id_statusBarang ='$id_statusBarang', keterangan ='$keterangan' WHERE id_laporan='$tangkap_id_laporan'");
                        echo "<script type='text/javascript'>window.top.location='laporan.php';</script>"; exit;
                      }
                    ?>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
        <footer class="footer">
          <div class="container-fluid clearfix">
            <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright © 2018
              <a href="http://www.bootstrapdash.com/" target="_blank">Bootstrapdash</a>. All rights reserved.</span>
            <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Hand-crafted & made with
              <i class="mdi mdi-heart text-danger"></i>
            </span>
          </div>
        </footer>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- plugins:js -->
  <script src="vendors/js/vendor.bundle.base.js"></script>
  <script src="vendors/js/vendor.bundle.addons.js"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="js/off-canvas.js"></script>
  <script src="js/misc.js"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="js/dashboard.js"></script>
  <!-- End custom js for this page-->
</body>

</html>