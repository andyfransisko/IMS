<?php

    include('../../connect.php');
    $id_ruangan = $_POST['idruangan'];
    $nama_ruangan = $_POST['namaruangan'];

    $query = mysqli_query($koneksi, "UPDATE ruangan SET nama_ruangan ='$nama_ruangan' WHERE id_ruangan='$tangkap_id_ruangan'");

    if($query)
    {
      header('location:ruangan.php');
    }
?>