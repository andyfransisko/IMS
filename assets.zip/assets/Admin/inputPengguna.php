<!DOCTYPE html>
<html lang="en">
<?php
SESSION_START();
$idsaya = $_SESSION['myid'];
include('../../connect.php');
?>
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Inventory LAB Systems</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="vendors/iconfonts/mdi/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="vendors/css/vendor.bundle.base.css">
  <link rel="stylesheet" href="vendors/css/vendor.bundle.addons.css">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="css/style.css">
  <!-- endinject -->
  <link rel="icon" href="../img/logo2.png" type="image/x-icon"/>
</head>

<body>
   <?php
     include('split/head.php');

     include('split/left.php');
    ?>
    <?php
      $query = mysqli_query($koneksi, "SELECT * FROM pengguna " );

      $checkBaris = mysqli_num_rows($query);
      $PK = 100001 + $checkBaris;
    ?>
    
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-lg-12 grid-margin">
              <div class="card">
                <div class="card-body"> 
                  <h4 class="card-title">Form Input Pengguna</h4>

                    <form class="forms-sample" method="POST" action="prosesInputPengguna.php">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">ID Pengguna</label>
                          <div class="col-sm-9">
                            <input type="Text" class="form-control" name="idpengguna" id="PKPSA"readonly
                            value="<?php
                              echo "PSA".$PK;
                            ?>">
                          </div>
                        </div>
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Tipe User</label>
                          <div class="col-sm-9">
                            <select name="idstatus" class="form-control">
                              <?php
                              $query_status = mysqli_query($koneksi, "SELECT * FROM status");
                              while($data = mysqli_fetch_array($query_status))
                              {
                                ?>
                                <option value="<?php echo $data['id_status']; ?>">
                                <?php echo $data['id_status']." - ".$data['nama_status']; ?>
                              </option>
                              <?php } ?>
                            </select>
                          </div>
                        </div>
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Nama Lengkap</label>
                          <div class="col-sm-9">
                            <input type="text" class="form-control" name="namalengkap" id="" placeholder="Nama lengkap" >
                          </div>
                        </div>
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Email</label>
                          <div class="col-sm-9">
                            <input type="email" class="form-control" name="email" id="" placeholder="Email">
                          </div>
                        </div>
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Kata Sandi</label>
                          <div class="col-sm-9">
                            <input type="password" class="form-control" name="katasandi" id="" placeholder="Kata Sandi">
                          </div>
                        </div>
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Tanggal Lahir</label>
                          <div class="col-sm-9">
                            <input type="date" class="form-control" name="tanggallahir" id="" placeholder="Tanggal Lahir" >
                          </div>
                        </div>
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Alamat</label>
                          <div class="col-sm-9">
                            <input type="text" class="form-control" name="alamat" id="" placeholder="Alamat">
                          </div>
                        </div>
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">No. HP</label>
                          <div class="col-sm-9">
                            <input type="number" class="form-control" name="nohp" id="" placeholder = "No HP">
                          </div>
                        </div>
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Tanggal Masuk</label>
                          <div class="col-sm-9">
                            <input type="date" class="form-control" name="tanggalmasuk" id="" >
                          </div>
                        </div>
                        <!--
                        <div class="form-group">
                          <div class="row">
                            <legend class="col-form-label col-sm-2 pt-0">Status Pengguna</legend>
                            <div class="form-check">
                              <input class="form-check-input" type="radio" name="statuspengguna" id="1" value="1" checked>
                              <label class="form-check-label" for="exampleRadios1">
                                Aktif
                              </label>
                            </div>
                            <div class="form-check">
                              <input class="form-check-input" type="radio" name="statuspengguna" id="0" value="0">
                              <label class="form-check-label" for="exampleRadios2">
                                Tidak Aktif
                              </label>
                            </div>
                          </div>
                        </div>-->
                        <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Status Pengguna</label>
                          <div class="col-sm-4">
                            <div class="form-radio">
                              <label class="form-check-label">
                                <input type="radio" class="form-check-input" name="statuspengguna" id="1" value="1" checked> Aktif
                              </label>
                            </div>
                          </div>
                          <div class="col-sm-5">
                            <div class="form-radio">
                              <label class="form-check-label">
                                <input type="radio" class="form-check-input" name="statuspengguna" id="0" value="0"> Tidak Aktif
                              </label>
                            </div>
                          </div>
                        </div>
                      </div>

                        <button type="submit" class="btn btn-success mr-2" name="submit">Submit</button>
                        <a href="pengguna.php"><button class="btn btn-light">Cancel</button></a>
                    </form>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
        <footer class="footer">
          <div class="container-fluid clearfix">
            <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright © 2018
              <a href="http://www.bootstrapdash.com/" target="_blank">Bootstrapdash</a>. All rights reserved.</span>
              <span class="float-none float-sm-right  mt-1 mt-sm-0 text-center" style ="color: #000f99;">
                <b>SISTECH UPH</b>
              </span>
            </span>
          </div>
        </footer>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- plugins:js -->
  <script src="vendors/js/vendor.bundle.base.js"></script>
  <script src="vendors/js/vendor.bundle.addons.js"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="js/off-canvas.js"></script>
  <script src="js/misc.js"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="js/dashboard.js"></script>
  <!-- End custom js for this page-->
</body>

</html>