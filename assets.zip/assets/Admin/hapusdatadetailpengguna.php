<?php
include('../../connect.php');
$tangkap_id_detailPengguna = $_GET['id'];

$query = mysqli_query($koneksi,"DELETE from detail_pengguna where id_detailPengguna ='$tangkap_id_detailPengguna'");

if($query){
  header('location:detailPengguna.php');
}
?>