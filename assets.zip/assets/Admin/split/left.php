<!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_sidebar.html -->
      <nav class="sidebar sidebar-offcanvas" id="sidebar">
        <ul class="nav">
          <li class="nav-item nav-profile">
            <div class="nav-link">
              <div class="user-wrapper">
                <div class="profile-image">
                  <img src="../img/anon.png" alt="profile image">
                </div>
                <div class="text-wrapper">
                  <p class="profile-name">
                  <?php
                      echo $_SESSION['myname']; 
                    ?>
                  </p>
                  <div>
                    <small class="designation text-muted">
                    <?php
                      echo $_SESSION['mystatus']; 
                    ?>
                    </small>
                    <span class="status-indicator online"></span>
                  </div>
                </div>
              </div>
            </div>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="dashboard.php">
              <i class="menu-icon mdi mdi-home-outline"></i>
              <span class="menu-title">Dashboard</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#drop1" aria-expanded="false" aria-controls="ui-basic">
              <i class="menu-icon mdi mdi-table"></i>
              <span class="menu-title">Master Data</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="drop1">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item">
                  <a class="nav-link" href="pengguna.php">Pengguna</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="ruangan.php">Ruangan</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="barang.php">Barang</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="pengecekan.php">Pengecekan</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="detailPengguna.php">Detail Pengguna</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="jenisBarang.php">Jenis Barang</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="laporan.php">Laporan</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="status.php">Status</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="statusBarang.php">Status Barang</a>
                </li>
              </ul>
            </div>
          </li>
          <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#drop2" aria-expanded="false" aria-controls="ui-basic">
              <i class="menu-icon mdi mdi-television"></i>
              <span class="menu-title">Layout</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="drop2">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item">
                  <a class="nav-link" href="layout205.php">F 205</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="layout208.php">F 208</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="layout210.php">F 210</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="layout211.php">F 211</a>
                </li>
              </ul>
            </div>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="routine.php">
              <i class="menu-icon mdi mdi-backup-restore"></i>
              <span class="menu-title">Routine Check</span>
            </a>
          </li>
          
        </ul>
      </nav>
      <!-- partial -->