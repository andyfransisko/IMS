
            <?php
                include('../../connect.php');
                SESSION_START();
                if(isset($_POST['submit1']))
                {
                    $SMonitor = $_POST['statusmonitor'];
                    $SCPU = $_POST['statuscpu'];
                    $SKeyboard = $_POST['statuskeyboard'];
                    $SMouse = $_POST['statusmouse'];

                    $idsaya = $_SESSION['myid'];

                    $querycek = mysqli_query($koneksi, "SELECT * FROM pengecekan " );

                    $checkBaris = mysqli_num_rows($querycek);
                    $PK = 100001 + $checkBaris;
                    $PK1 = "CEK" . $PK;

                    /*
                    $queryinsert1 = mysqli_query($koneksi,
                    "INSERT INTO pengecekan
                    (id_pengecekan,id_pengguna,waktu_pengecekan,id_statusBarang,id_barang)
                    VALUES
                    ('s','$idsaya',NOW(),$SMonitor,$IDMonitor)");
*/

                    $queryinsert1 = mysqli_query($koneksi,
                    "INSERT INTO pengecekan (`id_pengecekan`, `id_pengguna`, 
                    `waktu_pengecekan`, `id_statusBarang`, `id_barang`) 
                    VALUES 
                    ('$PK1', '$idsaya', NOW(), '$SMonitor', 'B100001')");
                        

                }
            ?>