<!DOCTYPE html>
<html lang="en">

<head>
<?php
include('../../connect.php');

session_start();
?>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Inventory LAB Systems</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="vendors/iconfonts/mdi/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="vendors/css/vendor.bundle.base.css">
  <link rel="stylesheet" href="vendors/css/vendor.bundle.addons.css">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/style2.css">
  <!-- endinject -->
  <link rel="icon" href="../img/logo2.png" type="image/x-icon"/>

</head>

<body>
<?php
      session_start();

      $namasaya = $_SESSION['myname'];

      $idsaya = $_SESSION['myid'];

      $statussaya = $_SESSION['mystatus'];

      if(!isset($namasaya))
      {
        header('location:../../index.php');
      }
     
      
    /* Untuk Super Admin */
     if($statussaya == "Super Admin")
     {
        include('split/head.php');
      include('split/left.php');
     }

     /* Untuk Admin */
     else if($statussaya == "Admin")
     {
        include('split/head3.php');
      include('split/left3.php');
      
     }

     /* Untuk User */
     else if($statussaya == "User")
     {
        include('split/head3.php');
      include('split/left5.php');
     }
    ?>
    
      <div class="main-panel">
        <div class="content-wrapper">
  
         <?php
          include('../../connect.php');
          $tangkap_idR = $_GET['idR'] ? $_GET['idR'] : null;
          $tangkap_idI = $_GET['idI'] ? $_GET['idI'] : null;
         ?>
          <div class="row">
            <div class="col-12 grid-margin">
              <div class="card">
                <div class="card-body">
                  <a href = "layout208.php"  >
                    <button type="button" class="btn btn-primary btn-rounded btn-fw float-left ">BACK</button><br>
                  </a>
                  
                  <br>
                  
                  <center><h1>Layout <?php echo $tangkap_idI ?></h1></center>
                  <div class="fluid-container">
                    <center>
                     <?php

              $IDJB11 = "JB100004";
              $IDJB12 = "JB100001";
              $IDJB13 = "JB100002";
              $IDJB14 = "JB100003";

              $queryAmbilData1 = mysqli_query($koneksi, 
              "SELECT statusBarang FROM status_barang 
               JOIN pengecekan ON
               status_barang.id_statusBarang = pengecekan.id_statusBarang
               JOIN barang ON
               barang.id_barang = pengecekan.id_barang
               JOIN jenis_barang ON
               barang.id_jenisBarang = jenis_barang.id_jenisBarang
               JOIN ruangan ON
               barang.id_ruangan = ruangan.id_ruangan
               
               WHERE ruangan.id_ruangan = '$tangkap_idR'
               AND jenis_barang.id_jenisBarang = '$IDJB11'
               AND barang.index_barang = '$tangkap_idI' ORDER BY id_pengecekan DESC LIMIT 1" );
              $StatusBarang1 = mysqli_fetch_assoc($queryAmbilData1);
              $hasil1  = $StatusBarang1['statusBarang'];

              /*
              $queryAmbilData2 = mysqli_query($koneksi, 
              "SELECT statusBarang FROM status_barang 
               JOIN pengecekan ON
               status_barang.id_statusBarang = pengecekan.id_statusBarang
               JOIN barang ON
               barang.id_barang = pengecekan.id_barang
               JOIN jenis_barang ON
               barang.id_jenisBarang = jenis_barang.id_jenisBarang
               JOIN ruangan ON
               barang.id_ruangan = ruangan.id_ruangan
               
               WHERE ruangan.id_ruangan = '$tangkap_idR'
               AND jenis_barang.id_jenisBarang = '$IDJB12'
               AND barang.index_barang = '$tangkap_idI' " );
              $StatusBarang2 = mysqli_fetch_assoc($queryAmbilData2);
              $hasil2  = $StatusBarang2['statusBarang'];
                */
              $queryAmbilData3 = mysqli_query($koneksi, 
              "SELECT statusBarang FROM status_barang 
               JOIN pengecekan ON
               status_barang.id_statusBarang = pengecekan.id_statusBarang
               JOIN barang ON
               barang.id_barang = pengecekan.id_barang
               JOIN jenis_barang ON
               barang.id_jenisBarang = jenis_barang.id_jenisBarang
               JOIN ruangan ON
               barang.id_ruangan = ruangan.id_ruangan
               
               WHERE ruangan.id_ruangan = '$tangkap_idR'
               AND jenis_barang.id_jenisBarang = '$IDJB13'
               AND barang.index_barang = '$tangkap_idI' ORDER BY id_pengecekan DESC LIMIT 1" );
              $StatusBarang3 = mysqli_fetch_assoc($queryAmbilData3);
              $hasil3  = $StatusBarang3['statusBarang'];

              $queryAmbilData4 = mysqli_query($koneksi, 
              "SELECT statusBarang FROM status_barang 
               JOIN pengecekan ON
               status_barang.id_statusBarang = pengecekan.id_statusBarang
               JOIN barang ON
               barang.id_barang = pengecekan.id_barang
               JOIN jenis_barang ON
               barang.id_jenisBarang = jenis_barang.id_jenisBarang
               JOIN ruangan ON
               barang.id_ruangan = ruangan.id_ruangan
               
               WHERE ruangan.id_ruangan = '$tangkap_idR'
               AND jenis_barang.id_jenisBarang = '$IDJB14'
               AND barang.index_barang = '$tangkap_idI' ORDER BY id_pengecekan DESC LIMIT 1" );
              $StatusBarang4 = mysqli_fetch_assoc($queryAmbilData4);
              $hasil4  = $StatusBarang4['statusBarang'];
            
            ?>
                    Monitor : <?php echo $hasil1;  ?><br>
                    Mouse : <?php echo $hasil3;  ?><br>
                    Keyboard : <?php echo $hasil4;  ?><br>
                    <?php
                  if($statussaya == "User")
                  {
                     ?>
                    <a href = "inputLaporan.php?idR=<?php echo $tangkap_idR; ?>&idI=<?php echo $tangkap_idI; ?>">
                    <button type="button" class="btn btn-danger btn-rounded btn-fw  ">REPORT</button><br>
                  </a>
                    <?php
                  }
                  ?>
                    </center>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
        <footer class="footer">
          <div class="container-fluid clearfix">
            <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright © 2018
              <a href="http://www.bootstrapdash.com/" target="_blank">Bootstrapdash</a>. All rights reserved.</span>
              <span class="float-none float-sm-right  mt-1 mt-sm-0 text-center" style ="color: #000f99;">
                <b>SISTECH UPH</b>
              </span>
          </div>
        </footer>

        

        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- plugins:js -->
  <script src="vendors/js/vendor.bundle.base.js"></script>
  <script src="vendors/js/vendor.bundle.addons.js"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="js/off-canvas.js"></script>
  <script src="js/misc.js"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="js/dashboard.js"></script>
  <!-- End custom js for this page-->
</body>

</html>