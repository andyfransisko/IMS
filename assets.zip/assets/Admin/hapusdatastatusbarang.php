<?php
include('../../connect.php');
$tangkap_id_statusBarang = $_GET['id'];
$status_delete = "0";

$query = mysqli_query($koneksi, "UPDATE status_barang SET user_delete='$idsaya',waktu_delete=NOW(),status_delete='$status_delete' WHERE id_statusBarang ='$tangkap_id_statusBarang'");

if($query){
  header('location:statusBarang.php');
}
?>