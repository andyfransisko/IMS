<?php
include('../../connect.php');
$tangkap_id_barang = $_GET['id'];
$status_delete = "0";

$query = mysqli_query($koneksi, 
"UPDATE barang 
SET user_delete='$idsaya',waktu_delete=NOW(),
status_delete='$status_delete' 
WHERE id_barang ='$tangkap_id_barang'");

if($query){
  echo "<script type='text/javascript'>window.top.location='barang.php';</script>"; exit;
}
?>