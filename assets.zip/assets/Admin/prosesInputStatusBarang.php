<?php
if(isset($_POST['submit']))
{
	include('../../connect.php');
	$statusBarang = $_POST['statusbarang'];
	$id_statusBarang = $_POST['idstatusbarang'];
	SESSION_START();
	$idsaya = $_SESSION['myid'];

	$query = mysqli_query($koneksi, "INSERT INTO status_barang (id_statusBarang,statusBarang,user_add,waktu_add,status_delete) VALUES ('$id_statusBarang','$statusBarang','$idsaya', NOW(),'1')");

	if(!$query)
	{
		echo "Gagal Simpan Data";
	}
	header('location:statusBarang.php');
	}
	else
	{
	header('location:statusBarang.php');
	}
?>