<?php
require('fpdf/fpdf.php');
require('../../connect.php');
class PDF extends FPDF {
	function Header()
	{
		$this->SetFont('Arial','B',15);
		$this->Ln(5);
	}
	function Footer()
	{
		$this->SetY(-10);
		$this->setFont('Arial','B',10);
		$this->Cell(0,0,'SISTECH UPH',0,0,'R');
		$this->Cell(0,10,'Page '.$this->PageNo()." / {pages}",0,0,'C');
	}
}

$pdf = new PDF('p','mm','A4');
$pdf->SetAutoPageBreak(true,15);
$pdf->AliasNbPages('{pages}');
$pdf->AddPage();
$pdf->setFONT('Arial','',20);
$pdf->Image('logo.png',10,10,50);
$pdf->Cell(189,30,'',0,1);
$pdf->Cell(189,5,'REPORT',0,1,'R');
$pdf->Cell(189,10,'',0,1);

//Tabel data
$pdf->setFONT('Arial','',10);
//Cell(width,height,'text',border,end-line)
$pdf->Cell(10,5,'No.',1,0);
$pdf->Cell(50,5,'ID Status',1,0);
$pdf->Cell(50,5,'Status',1,1);

$query = mysqli_query($koneksi, "SELECT * from status");
$nomor="1";
while($data = mysqli_fetch_array($query))
{
$pdf->Cell(10,5,$nomor,1,0);
$pdf->Cell(50,5,$data['id_status'],1,0);
$pdf->Cell(50,5,$data['nama_status'],1,1);
$nomor++;
}

//Space footer
$pdf->Cell(189,10,'',0,1);
$pdf->Output();