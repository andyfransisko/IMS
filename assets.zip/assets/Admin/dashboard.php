<!DOCTYPE html>
<html lang="en">

<head>
<?php 
include('../../connect.php');
session_start();

$namasaya = $_SESSION['myname'];

$idsaya = $_SESSION['myid'];

$statussaya = $_SESSION['mystatus'];

if(!isset($namasaya))
{
  header('location:../../index.php');
}
?>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Inventory LAB Systems</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="vendors/iconfonts/mdi/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="vendors/css/vendor.bundle.base.css">
  <link rel="stylesheet" href="vendors/css/vendor.bundle.addons.css">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="css/style.css">
  <!-- endinject -->
  <link rel="icon" href="../img/logo2.png" type="image/x-icon"/>
</head>

<body>
   <?php

    /* Untuk Super Admin */
     if($statussaya == "Super Admin")
     {
      include('split/head.php');
      include('split/left.php');
     }

     /* Untuk Admin */
     else if($statussaya == "Admin")
     {
      include('split/head3.php');
      include('split/left3.php');
     }

     /* Untuk User */
     else if($statussaya == "User")
     {
      include('split/head3.php');
      include('split/left5.php');
     }
    ?>
    
    <?php

$queryAmbilMonitor1 = mysqli_query($koneksi, 
"SELECT waktu_pengecekan FROM pengecekan
 JOIN barang ON
 pengecekan.id_barang = barang.id_barang
 JOIN ruangan ON
 barang.id_ruangan = ruangan.id_ruangan
 JOIN jenis_barang ON
 barang.id_jenisBarang = jenis_barang.id_jenisBarang
 
 
 WHERE ruangan.id_ruangan = 'R100001'
 AND jenis_barang.id_jenisBarang = 'JB100001'
 AND barang.index_barang = '1'
 ORDER BY waktu_pengecekan DESC LIMIT 1 " );
 $waktuCekMonitor1 = mysqli_fetch_assoc($queryAmbilMonitor1);
 $hasilWaktu1 = $waktuCekMonitor1['waktu_pengecekan'];


 $queryAmbilMonitor2 = mysqli_query($koneksi, 
"SELECT waktu_pengecekan FROM pengecekan
 JOIN barang ON
 pengecekan.id_barang = barang.id_barang
 JOIN ruangan ON
 barang.id_ruangan = ruangan.id_ruangan
 JOIN jenis_barang ON
 barang.id_jenisBarang = jenis_barang.id_jenisBarang
 
 
 WHERE ruangan.id_ruangan = 'R100001'
 AND jenis_barang.id_jenisBarang = 'JB100001'
 AND barang.index_barang = '1'
 ORDER BY waktu_pengecekan DESC LIMIT 1 " );
 $waktuCekMonitor2 = mysqli_fetch_assoc($queryAmbilMonitor2);
 $hasilWaktu2 = $waktuCekMonitor2['waktu_pengecekan'];


 $queryAmbilMonitor3 = mysqli_query($koneksi, 
"SELECT waktu_pengecekan FROM pengecekan
 JOIN barang ON
 pengecekan.id_barang = barang.id_barang
 JOIN ruangan ON
 barang.id_ruangan = ruangan.id_ruangan
 JOIN jenis_barang ON
 barang.id_jenisBarang = jenis_barang.id_jenisBarang
 
 
 WHERE ruangan.id_ruangan = 'R100001'
 AND jenis_barang.id_jenisBarang = 'JB100001'
 AND barang.index_barang = '1'
 ORDER BY waktu_pengecekan DESC LIMIT 1 " );
 $waktuCekMonitor3 = mysqli_fetch_assoc($queryAmbilMonitor3);
 $hasilWaktu3 = $waktuCekMonitor3['waktu_pengecekan'];

 $queryAmbilMonitor4 = mysqli_query($koneksi, 
"SELECT waktu_pengecekan FROM pengecekan
 JOIN barang ON
 pengecekan.id_barang = barang.id_barang
 JOIN ruangan ON
 barang.id_ruangan = ruangan.id_ruangan
 JOIN jenis_barang ON
 barang.id_jenisBarang = jenis_barang.id_jenisBarang
 
 
 WHERE ruangan.id_ruangan = 'R100001'
 AND jenis_barang.id_jenisBarang = 'JB100001'
 AND barang.index_barang = '1'
 ORDER BY waktu_pengecekan DESC LIMIT 1 " );
 $waktuCekMonitor4 = mysqli_fetch_assoc($queryAmbilMonitor4);
 $hasilWaktu4 = $waktuCekMonitor4['waktu_pengecekan'];


?>
    
      


      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 grid-margin stretch-card">
              <div class="card card-statistics">
                <div class="card-body">
                  <div class="clearfix">
                    <div class="float-left">
                      <i class="mdi mdi-poll-box text-danger icon-lg"></i>
                    </div>
                    <div class="float-right">
                      <p class="mb-0 text-right">Last Checked : 
                      <?php
                      echo "<br>";
                        echo $hasilWaktu1;
                      ?>
                      </p>
                      <div class="fluid-container">
                        <h3 class="font-weight-medium text-right mb-0">F 205</h3>
                      </div>
                    </div>
                  </div>
                  <p class="text-muted mt-3 mb-0">
                  <i class="mdi mdi-calendar mr-1" aria-hidden="true"></i> <?php echo $hasilWaktu1; ?>
                  </p>
                </div>
              </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 grid-margin stretch-card">
              <div class="card card-statistics">
                <div class="card-body">
                  <div class="clearfix">
                    <div class="float-left">
                      <i class="mdi mdi-poll-box text-warning icon-lg"></i>
                    </div>
                    <div class="float-right">
                      <p class="mb-0 text-right">Last Checked :</p>
                      <div class="fluid-container">
                        <h3 class="font-weight-medium text-right mb-0">F 208</h3>
                      </div>
                    </div>
                  </div>
                  <p class="text-muted mt-3 mb-0">
                  <i class="mdi mdi-calendar mr-1" aria-hidden="true"></i> <?php echo $hasilWaktu2; ?>
                  </p>
                </div>
              </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 grid-margin stretch-card">
              <div class="card card-statistics">
                <div class="card-body">
                  <div class="clearfix">
                    <div class="float-left">
                      <i class="mdi mdi-poll-box text-success icon-lg"></i>
                    </div>
                    <div class="float-right">
                      <p class="mb-0 text-right">Last Checked :</p>
                      <div class="fluid-container">
                        <h3 class="font-weight-medium text-right mb-0">F 210</h3>
                      </div>
                    </div>
                  </div>
                  <p class="text-muted mt-3 mb-0">
                    <i class="mdi mdi-calendar mr-1" aria-hidden="true"></i> <?php echo $hasilWaktu3; ?>
                  </p>
                </div>
              </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 grid-margin stretch-card">
              <div class="card card-statistics">
                <div class="card-body">
                  <div class="clearfix">
                    <div class="float-left">
                      <i class="mdi mdi-poll-box text-info icon-lg"></i>
                    </div>
                    <div class="float-right">
                      <p class="mb-0 text-right">Last Checked : </p>
                      <div class="fluid-container">
                        <h3 class="font-weight-medium text-right mb-0">F 211</h3>
                      </div>
                    </div>
                  </div>
                  <p class="text-muted mt-3 mb-0">
                  <i class="mdi mdi-calendar mr-1" aria-hidden="true"></i> <?php echo $hasilWaktu4; ?>
                  </p>
                </div>
              </div>
            </div>
          </div>
          
          <div class="row">
            <div class="col-lg-12 grid-margin">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Pengecekan Terkini</h4>
                  <div class="table-responsive">
                    <table class="table table-bordered">
                      <thead>
                        <tr>
                          <th>
                            #
                          </th>
                          <th>
                            Pengecek
                          </th>
                          <th>
                            Waktu Pengecekan
                          </th>
                          <th>
                            Nama Barang
                          </th>
                          <th>
                            Status Barang
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php
                          include('../../connect.php');
                        ?>
                        <?php
                          $query = mysqli_query($koneksi,"SELECT * FROM pengecekan JOIN pengguna ON pengecekan.id_pengguna=pengguna.id_pengguna JOIN barang ON pengecekan.id_barang=barang.id_barang JOIN status_barang ON pengecekan.id_statusBarang=status_barang.id_statusBarang ORDER BY id_pengecekan LIMIT 5");
                          $no="1";
                          while($data = mysqli_fetch_array($query))
                          {
                        ?>
                        <tr>
                          <td><?php echo $no; $no++; ?></td>
                          <td><?php echo $data['nama_lengkap'];?></td>
                          <td><?php echo $data['waktu_pengecekan'];?></td>
                          <td><?php echo $data['nama_barang'];?></td>
                          <td><?php echo $data['statusBarang'];?></td>
                          
                        </tr>
                        <?php
                        }  ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <?php
          $queryceklap = mysqli_query($koneksi, 
          "SELECT * FROM `laporan`" );
          while($data=mysqli_fetch_array($queryceklap))
          {
          ?>
          <div class="row">
            <div class="col-12 grid-margin">
              <div class="card">
                <div class="card-body">
                  <h5 class="card-title mb-4">Laporan Kerusakan</h5>
                  <div class="fluid-container">
                    <div class="row ticket-card mt-3 pb-2 border-bottom pb-3 mb-3">
                      <div class="col-md-1">
                        <img class="img-sm rounded-circle mb-4 mb-md-0" src="../img/anon.jpg" alt="profile image">
                      </div>
                      <div class="ticket-details col-md-9">
                        <div class="d-flex">
                          <p class="text-dark font-weight-semibold mr-2 mb-0 no-wrap">
                          <?php
                            $pengguna =$data['id_pengguna'];

                            $queryA1=mysqli_query($koneksi,
                            "SELECT nama_lengkap FROM pengguna
                            WHERE id_pengguna = '$pengguna'");
                            $S1 = mysqli_fetch_assoc($queryA1);
                            $nama  = $S1['nama_lengkap'];

                            echo $nama; 

                          ?>
                           :</p>
                          <p class="text-primary mr-1 mb-0">
                          <?php
                          $ruangan =$data['id_ruangan'];

                          $queryA2=mysqli_query($koneksi,
                          "SELECT nama_ruangan FROM ruangan
                          WHERE id_ruangan = '$ruangan'");
                          $S2 = mysqli_fetch_assoc($queryA2);
                          $ruangan  = $S2['nama_ruangan'];

                          echo $ruangan; 
                          
                          ?></p>

                        </div>
                        <p class="text-gray ellipsis mb-2">
                        <?php

                          $JB = $data['id_jenisBarang'];
                          $indeks = $data['index_barang'];

                        

                          $status =$data['id_statusBarang'];

                          $queryA3=mysqli_query($koneksi,
                          "SELECT statusBarang FROM status_barang
                          WHERE id_statusBarang = '$status'");
                          $S3 = mysqli_fetch_assoc($queryA3);
                          $status  = $S3['statusBarang'];

                          $queryA4=mysqli_query($koneksi,
                          "SELECT nama_barang FROM barang
                          WHERE id_jenisBarang = '$JB'");
                          $S4 = mysqli_fetch_assoc($queryA4);
                          $barang  = $S4['nama_barang'];


                          echo $barang;
                        echo ", Status : ";
                        echo $status;
                        ?>
                        </p>
                        <p class="text-gray ellipsis mb-2">
                        <?php

                        echo "Keterangan : ";
                        echo $data['keterangan'];
                        ?>
                        </p>
                        <div class="row text-gray d-md-flex d-none">
                          <div class="col-4 d-flex">
                            <small class="mb-0 mr-2 text-muted text-muted">
                            <?php
                            echo "Tanggal Lapor : "; echo $data['waktu_laporan'];
                            ?>
                            </small>
                            
                          </div>
                          
                        </div>
                      </div>
                      
                    </div>
                    <?php
          }
          ?>
                    
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
        <footer class="footer">
          <div class="container-fluid clearfix">
            <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright © 2018
              <a href="http://www.bootstrapdash.com/" target="_blank">Bootstrapdash</a>. All rights reserved.</span>
              <span class="float-none float-sm-right  mt-1 mt-sm-0 text-center" style ="color: #000f99;">
                <b>SISTECH UPH</b>
              </span>
          </div>
        </footer>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- plugins:js -->
  <script src="vendors/js/vendor.bundle.base.js"></script>
  <script src="vendors/js/vendor.bundle.addons.js"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="js/off-canvas.js"></script>
  <script src="js/misc.js"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="js/dashboard.js"></script>
  <!-- End custom js for this page-->
</body>

</html>