<?php

if (SESSION_STATUS() == PHP_SESSION_NONE)
{
    SESSION_START();
}

SESSION_DESTROY();
header('location:../../index.php');

?>