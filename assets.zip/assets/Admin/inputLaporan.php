<!DOCTYPE html>
<html lang="en">
<?php
include('../../connect.php');
?>
<head>
  
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Inventory LAB Systems</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="vendors/iconfonts/mdi/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="vendors/css/vendor.bundle.base.css">
  <link rel="stylesheet" href="vendors/css/vendor.bundle.addons.css">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="css/style.css">
  
  <!-- endinject -->
  <link rel="icon" href="../img/logo2.png" type="image/x-icon"/>
</head>

<body>
   <?php
     include('split/head3.php');

     include('split/left5.php');
    ?>

    <?php
    $tangkap_idR = $_GET['idR'] ? $_GET['idR'] : null;
    $tangkap_idI = $_GET['idI'] ? $_GET['idI'] : null;
    ?>

      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-lg-12 grid-margin">
              <div class="card">
                <div class="card-body"> 
                  <h4 class="card-title">Form Laporan</h4>
                  
                    <form class="forms-sample" method="POST">
                    <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Ruangan</label>
                          <div class="col-sm-9">
                            <input type="Text" class="form-control" name="ruangan" id="PKB" readonly
                            value="<?php
                                $query1 = mysqli_query($koneksi, 
                                "SELECT nama_ruangan FROM ruangan
                                  WHERE id_ruangan = '$tangkap_idR'" );
                                  $OK1 = mysqli_fetch_assoc($query1);
                                  $Ruangan  = $OK1['nama_ruangan'];
                            
                                  echo $Ruangan;
                            ?>" >
                          </div>
                        </div>
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Jenis Barang</label>
                          <div class="col-sm-9">
                          <select name="idjenisbarang"  class="form-control">
                              <option value = "JB100004">
                                Monitor
                              </option>
                              <option value = "JB100002">
                                Mouse
                              </option>
                              <option value = "JB100003">
                                Keyboard
                              </option>
                            </select>
                          </div>
                        </div>
                        
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Status Barang</label>
                          <div class="col-sm-9">
                            <select name="idstatusbarang" class="form-control">
                              <?php
                              $query_ruangan = mysqli_query($koneksi, "SELECT * FROM status_barang");
                              while($data = mysqli_fetch_array($query_ruangan))
                              {
                                ?>
                                <option value="<?php echo $data['id_statusBarang']; ?>">
                                <?php echo $data['statusBarang']; ?>
                              </option>
                              <?php } ?>
                            </select>
                          </div>
                        </div>
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">KETERANGAN</label>
                          <div class="col-sm-9">
                            <input type="text" class="form-control" name="keterangan" id="" placeholder="Keterangan">
                          </div>
                        </div>
                        
                        <button type="submit" class="btn btn-success mr-2" name="submit">Submit</button>
                        <a href="layout205.php"><button type="button"class="btn btn-light">Cancel</button></a>
                    </form>

                    <?php
                    if(isset($_POST['submit']))
                    {
                      include('../../connect.php');
                      SESSION_START();
                      $idsaya = $_SESSION['myid'];
                      $ruangan = $_POST['ruangan'];
                      $id_statusBarang = $_POST['idstatusbarang'];
                      $id_jenisBarang = $_POST['idjenisbarang'];
                      
                      $keterangan = $_POST['keterangan'];
                      
                      $querycek = mysqli_query($koneksi, "SELECT * FROM laporan " );

                      $checkBaris = mysqli_num_rows($querycek);
                      $PK = 100001 + $checkBaris;
                      $PK1 = "LAP".$PK;

                      $querycek1 = mysqli_query($koneksi, "SELECT id_ruangan FROM ruangan
                      WHERE nama_ruangan='$ruangan' " );
                      $A1 = mysqli_fetch_assoc($querycek1);
                      $hasilRuangan  = $A1['id_ruangan'];

                      $query5 = mysqli_query($koneksi, "INSERT INTO `laporan` 
                      (`id_laporan`, `id_pengguna`, `waktu_laporan`, `id_ruangan`, 
                      `index_barang`, `id_jenisBarang`, `id_statusBarang`, 
                      `keterangan`) 
                      VALUES 
                      ('$PK1', '$idsaya', NOW(), '$hasilRuangan', '$tangkap_idI', 
                      '$id_jenisBarang', '$id_statusBarang', '$keterangan')");

                      if(!$query5)
                      {
                        echo "Gagal Simpan Data";
                        echo "$PK1";
                        echo "$idsaya";
                        echo "$ruangan";
                        echo "$tangkap_idI";
                        echo "$id_jenisBarang";
                        echo "$id_statusBarang";
                        echo "$keterangan";
                      }
                      echo "<script type='text/javascript'>window.top.location='layout205.php';</script>"; exit;
                    }
                    else
                    {
                      header('location:layout205.php');
                    }
                    ?>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
        <footer class="footer">
          <div class="container-fluid clearfix">
            <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright © 2018
              <a href="http://www.bootstrapdash.com/" target="_blank">Bootstrapdash</a>. All rights reserved.</span>
            <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Hand-crafted & made with
              <i class="mdi mdi-heart text-danger"></i>
            </span>
          </div>
        </footer>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- plugins:js -->
  <script src="vendors/js/vendor.bundle.base.js"></script>
  <script src="vendors/js/vendor.bundle.addons.js"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="js/off-canvas.js"></script>
  <script src="js/misc.js"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="js/dashboard.js"></script>
  <!-- End custom js for this page-->
</body>



<script src="jquery.js">


</html>