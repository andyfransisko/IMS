<?php
if(session_status()==PHP_SESSION_NONE)
  session_start();
$namasaya = $_SESSION['myname'];
$idsaya = $_SESSION['myid'];
if(!isset($namasaya))
{
  header('location:../../index.php');
}
?>
<?php
include('../../connect.php');
      $querycek5 = mysqli_query($koneksi, "SELECT * FROM `pesan_detail` WHERE id_penggunaKe = '$idsaya' AND status_pesan = '1'" );

                  $checkBaris1 = mysqli_num_rows($querycek5); 
                  ?>

<div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <nav class="navbar default-layout col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
      <div class="text-center navbar-brand-wrapper d-flex align-items-top justify-content-center">
        <a class="navbar-brand brand-logo" href="dashboard.php">
          <img src="images/logo3.png" alt="logo" />
        </a>
        <a class="navbar-brand brand-logo-mini" href="index.html">
          <img src="images/logo2.png" alt="logo" />
        </a>
      </div>
      <div class="navbar-menu-wrapper d-flex align-items-center">
        <ul class="navbar-nav navbar-nav-left header-links d-none d-md-flex">
          <li class="nav-item active">
            <a href="dashboard.php" class="nav-link">Homepage
            </a>
          </li>
          <li class="nav-item">
            <a href="report.php" class="nav-link">
              <i class="mdi mdi-elevation-rise"></i>Reports</a>
          </li>
        </ul>
        <ul class="navbar-nav navbar-nav-right">
          <li class="nav-item dropdown">
            <a class="nav-link count-indicator dropdown-toggle" id="messageDropdown" href="#" data-toggle="dropdown" aria-expanded="false">
              <i class="mdi mdi-file-document-box"></i>
              <span class="count"><?php echo $checkBaris1; ?></span>
            </a>
            <div class="dropdown-menu dropdown-menu-right navbar-dropdown preview-list" aria-labelledby="messageDropdown">
              <div class="dropdown-item">
                <p class="mb-0 font-weight-normal float-left">
                <?php
                if($checkBaris1 > 0)
                {
                  echo "You have ".$checkBaris1." unread mails"; 
                }
                else
                {
                  echo "No unread mails";
                }
                ?>
                
                </p>
                <span class="badge badge-info badge-pill float-right">View all</span>
              </div>
              <a href="pesan.php">
              <div class="dropdown-item">
                <p class="mb-0 font-weight-normal float-left">Send Messages
                </p>
                </a>
            </div>
            
                  <?php
                  while($data=mysqli_fetch_array($querycek5))
                  {

                    $idP = $data['id_penggunaDari'];
                  $querynama = mysqli_query($koneksi,"SELECT nama_lengkap FROM pengguna 
                  WHERE id_pengguna = '$idP'");
                  $hasil1 = mysqli_fetch_assoc($querynama);
                  $hasilnama  = $hasil1['nama_lengkap'];
                  
                  ?>
                  
                <div class="dropdown-divider"></div>
              <a class="dropdown-item preview-item" href = "pesandetail.php?idP=<?php echo $idP; ?>">
                <div class="preview-thumbnail">
                  <img src="../img/anon.png" alt="image" class="profile-pic">
                </div>
                
                <div class="preview-item-content flex-grow">
                  <h6 class="preview-subject ellipsis font-weight-medium text-dark"><?php 
                  
                  
                  echo $hasilnama;
                  
                   ?>
                   <!--
                    <span class="float-right font-weight-light small-text">
                    <?php
                    
                    $waktu = $data['tanggalWaktu'];
                    $querywaktu = mysqli_query($koneksi,
                    "SELECT DATE(tanggalWaktu) FROM pesan_detail
                    WHERE id_penggunaDari = '$idP'");
                    $hasilwaktu = mysqli_fetch_assoc($querywaktu);
                    $hasilwaktu1= $hasilwaktu['tanggalWaktu'];

                    echo $hasilwaktu1;
                    
                    ?>1 Minutes ago</span> !-->
                  </h6>
                  <p class="font-weight-light small-text">
                    <?php
                      $idT = $data['id_pesan'];
                      $querytopik = mysqli_query($koneksi,"SELECT topik_pesan FROM pesan
                      
                      WHERE id_pesan = '$idT'");
                      $hasil2 = mysqli_fetch_assoc($querytopik);
                      $hasiltopik  = $hasil2['topik_pesan'];
                      
                      echo $hasiltopik;
                    ?>
                  </p>
                </div>
              </a>
                <?php
                  }
                  ?>
                  
                
          </li>
   
          <li class="nav-item dropdown">
            <a class="nav-link count-indicator dropdown-toggle" id="notificationDropdown" href="#" data-toggle="dropdown">
              <i class="mdi mdi-bell"></i>
              <span class="count">4</span>
            </a>
            <div class="dropdown-menu dropdown-menu-right navbar-dropdown preview-list" aria-labelledby="notificationDropdown">
              <a class="dropdown-item">
                <p class="mb-0 font-weight-normal float-left">You have 4 new notifications
                </p>
                <span class="badge badge-pill badge-warning float-right">View all</span>
              </a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item preview-item">
                <div class="preview-thumbnail">
                  <div class="preview-icon bg-success">
                    <i class="mdi mdi-alert-circle-outline mx-0"></i>
                  </div>
                </div>
                <div class="preview-item-content">
                  <h6 class="preview-subject font-weight-medium text-dark">Application Error</h6>
                  <p class="font-weight-light small-text">
                    Just now
                  </p>
                </div>
              </a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item preview-item">
                <div class="preview-thumbnail">
                  <div class="preview-icon bg-warning">
                    <i class="mdi mdi-comment-text-outline mx-0"></i>
                  </div>
                </div>
                <div class="preview-item-content">
                  <h6 class="preview-subject font-weight-medium text-dark">Settings</h6>
                  <p class="font-weight-light small-text">
                    Private message
                  </p>
                </div>
              </a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item preview-item">
                <div class="preview-thumbnail">
                  <div class="preview-icon bg-info">
                    <i class="mdi mdi-email-outline mx-0"></i>
                  </div>
                </div>
                <div class="preview-item-content">
                  <h6 class="preview-subject font-weight-medium text-dark">New user registration</h6>
                  <p class="font-weight-light small-text">
                    2 days ago
                  </p>
                </div>
              </a>
            </div>
          </li>
          <li class="nav-item dropdown d-none d-xl-inline-block">
            <a class="nav-link dropdown-toggle" id="UserDropdown" href="#" data-toggle="dropdown" aria-expanded="false">
              <span class="profile-text">Hello, 
              <?php
                      echo $_SESSION['myname']; 
                    ?>
              </span>
              <img class="img-xs rounded-circle" src="../img/anon.png" alt="Profile image">
            </a>
            <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="UserDropdown">
              <a class="dropdown-item p-0">
                <div class="d-flex border-bottom">
                  <div class="py-3 px-4 d-flex align-items-center justify-content-center">
                    <i class="mdi mdi-bookmark-plus-outline mr-0 text-gray"></i>
                  </div>
                  <div class="py-3 px-4 d-flex align-items-center justify-content-center border-left border-right">
                    <i class="mdi mdi-account-outline mr-0 text-gray"></i>
                  </div>
                  <div class="py-3 px-4 d-flex align-items-center justify-content-center">
                    <i class="mdi mdi-alarm-check mr-0 text-gray"></i>
                  </div>
                </div>
              </a>
              <a href="kelolaakun.php" class="dropdown-item mt-2">
                Manage Accounts
              </a>
              <a href="gantikatasandi.php" class="dropdown-item">
                Change Password
              </a>
              <a class="dropdown-item" href = "logout.php">
                Sign Out
              </a>
            </div>
          </li>
        </ul>
        <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
          <span class="mdi mdi-menu"></span>
        </button>
      </div>
    </nav>